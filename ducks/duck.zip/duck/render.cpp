
bool GraphicsLoaded = false;


#define RGB(r, g, b) (0xFF000000 | ((b)<<16) | ((g)<<8) | (r))

// Textures
Texture duckTex;
Texture duckOutlineTex;

Texture crateTex;
Texture crateOutlineTex;

Texture gunTex;

Texture brickTex;
Texture skyTex;
Texture grassTex;

Texture fontTex;


int	initGraphics()
{
	setupGu();
	convertModels();

	// Projection Matrix
 	sceGumMatrixMode(GU_PROJECTION);
	sceGumLoadIdentity();
	sceGumPerspective(75.0f,16.0f/9.0f,0.5f,50.0f);
	//                fov, aspect,    near, far

	// Load textures
	grassTex.load("resources/grass.png");
	duckTex.load("resources/ducktex.png");
	crateTex.load("resources/crate.png");
	brickTex.load("resources/brick.png");
	gunTex.load("resources/guntex.png");
	skyTex.load("resources/sky.png");
	duckOutlineTex.load("resources/duckoutline.png");
	crateOutlineTex.load("resources/crateoutline.png");
	fontTex.load("resources/font.png");
	
	
	// Vram them
	
	// Always on the screen
//	skyTex.vram(); (save room for text, vram this later)
//	fontTex.vram();	
	gunTex.vram();

	
	// Sometimes on the screen
	grassTex.vram();
	duckTex.vram();
	brickTex.vram();
	crateTex.vram();

	// Outlines
	duckOutlineTex.vram();
	crateOutlineTex.vram();	

	GraphicsLoaded = true;
	
	return 1;
}

int	shutdownGraphics()
{
	// Unload all the textures
	grassTex.unload();
	duckTex.unload();
	crateTex.unload();
	brickTex.unload();
	gunTex.unload();
	skyTex.unload();
	duckOutlineTex.unload();
	crateOutlineTex.unload();
//	fontTex.unload();

	// Term the GU
	shutdownGu();

	return 1;
}


int drawFirstPerson()
{

	// First Person Drawing
	
	// Set to First Person
	sceGumMatrixMode(GU_VIEW);
	sceGumLoadIdentity();

	// No Depth Testing
	sceGuDisable(GU_DEPTH_TEST);
	
	sceGumMatrixMode(GU_MODEL);
	
	
	/*		The Gun		*/

	sceGumLoadIdentity();
	{
		ScePspFVector3 rot = { 0.0f, 180*toRads, 0.0f };
		ScePspFVector3 pos = { 0.0f, -0.32f+sin((Player1.bobAngle)*toRads)*0.02f, 0.32f };
		sceGumTranslate(&pos);	
		sceGumRotateXYZ(&rot);
	}

	gunTex.assign();
	sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,GUN_TRIANGLES*3,0,gunModel);



	// Turn Depth Testing Back On
	sceGuEnable(GU_DEPTH_TEST);	

	return 1;
}

int drawTerrain()
{
	int x, y;
	grassTex.assign();
	
	for (y = 0; y < MAP_HEIGHT; y++)
	{
		for (x = 0; x < MAP_WIDTH; x++)
		{
			sceGumLoadIdentity();
			{
				ScePspFVector3 pos = { x*2, 0, y*2 };
				ScePspFVector3 rot = { 0, 0, 0 };
				sceGumTranslate(&pos);
				sceGumRotateXYZ(&rot);
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,2*3,0,grass_vertices);
		}
	}

	return 1;
}

int drawDucks()
{
	int i;

	// Inner
	duckTex.assign();	

	for ( i = 0; i < MAX_PLAYERS; i++ )
	{
		if ( nodes[i].connected && nodes[i].physical->alive && nodes[i].physical != Player1.physical )
		{

			sceGumLoadIdentity();
			{
				ScePspFVector3 pos = { nodes[i].physical->Object->x, 0, nodes[i].physical->Object->y };
				ScePspFVector3 rot = { 0, nodes[i].physical->YRot*toRads, 0 };
				ScePspFVector3 scale = { 1.0f, 1.0f, 1.0f };
				sceGumTranslate(&pos);
				sceGumRotateXYZ(&rot);
				sceGumScale(&scale);
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,DUCK_TRIANGLES*3,0,duckModel);
		}
	}

	return 1;
}

int	drawDucksGuns()
{
	int i;

	gunTex.assign();

	for ( i = 0; i < MAX_PLAYERS; i++ )
	{
		if ( nodes[i].connected && nodes[i].physical->alive && nodes[i].physical != Player1.physical )
		{
			sceGumLoadIdentity();
			{
				ScePspFVector3 rot = { 0.0f, (nodes[i].physical->YRot+180)*toRads, 0.0f };
				ScePspFVector3 scale = { 0.4f, 0.4f, 0.4f };
				ScePspFVector3 pos = { nodes[i].physical->Object->x, 0.5f, nodes[i].physical->Object->y };
				sceGumTranslate(&pos);	
				sceGumRotateXYZ(&rot);
				sceGumScale(&scale);
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,GUN_TRIANGLES*3,0,gunModel);
		}
	}

	return 1;
}


int	drawDucksOutline()
{
	int i;

	// Outline
	duckOutlineTex.assign();	
	
	for ( i = 0; i < MAX_PLAYERS; i++ )
	{
		if ( nodes[i].connected && nodes[i].physical->alive && nodes[i].physical != Player1.physical )
		{
			sceGumLoadIdentity();
			{
				ScePspFVector3 pos1 = { 0, -0.25f, 0 };
				ScePspFVector3 pos = { nodes[i].physical->Object->x, 0.25f, nodes[i].physical->Object->y };
				ScePspFVector3 rot = {  nodes[i].physical->XRot*toRads, nodes[i].physical->YRot*toRads, 0 };
				ScePspFVector3 scale = { 1.05f, 1.05f, 1.05f };
				sceGumTranslate(&pos);
				sceGumRotateXYZ(&rot);
				sceGumScale(&scale);
				sceGumTranslate(&pos1);
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,DUCK_TRIANGLES*3,0,duckModel);
		}
	}	


	return 1;
}

int	drawBoxes()
{
	int i;
	crateTex.assign();
	
	for ( i = 0; i < MAX_BOXES; i++ )
	{
		if ( Boxes[i] != NULL )
		{


			sceGumLoadIdentity();
			{
				ScePspFVector3 pos = { Boxes[i]->Object->x, 0, Boxes[i]->Object->y };
				ScePspFVector3 rot = { 0, 0, 0 };
				ScePspFVector3 scale = { 1.0f, 1.0f, 1.0f };
				sceGumTranslate(&pos);
				sceGumRotateXYZ(&rot);
				sceGumScale(&scale);
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,CRATE_TRIANGLES*3,0,crateModel);
		}
	}

	return 1;
}

int	drawBoxesOutline()
{
	int i;
	crateOutlineTex.assign();
	
	for ( i = 0; i < MAX_BOXES; i++ )
	{
		if ( Boxes[i] != NULL )
		{


			sceGumLoadIdentity();
			{
				ScePspFVector3 pos1 = { 0.0f, -1.0f, 0.0f };
				ScePspFVector3 pos = { Boxes[i]->Object->x, 1.0f, Boxes[i]->Object->y };
				ScePspFVector3 rot = { 0, 0, 0 };
				ScePspFVector3 scale = { 1.05f, 1.05f, 1.05f };
				sceGumTranslate(&pos);
				sceGumRotateXYZ(&rot);
				sceGumScale(&scale);
				sceGumTranslate(&pos1);				
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,CRATE_TRIANGLES*3,0,crateModel);
		}
	}

	return 1;
}

int drawWalls()
{
	int x, y;
	
	brickTex.assign();
//	sceGuTexFilter(GU_NEAREST_MIPMAP_NEAREST,GU_NEAREST_MIPMAP_NEAREST);

	for ( y = 0; y < WALL_HEIGHT; y++ )
	{
		// Closest width wall
		for ( x = 1; x <= MAP_WIDTH/2; x++ )
		{
			sceGumLoadIdentity();
			{
				ScePspFVector3 pos = { x*4, y*WALL_HEIGHT, 0 };
				ScePspFVector3 rot = { 0, 180*toRads, 0 };
				sceGumTranslate(&pos);
				sceGumRotateXYZ(&rot);
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,2*3,0,wall_vertices);
		}

		// Furthest width wall
		for ( x = 0; x < MAP_WIDTH/2; x++ )
		{
			sceGumLoadIdentity();
			{
				ScePspFVector3 pos = { x*4, y*WALL_HEIGHT, 2*MAP_HEIGHT };
				ScePspFVector3 rot = { 0, 0, 0 };
				sceGumTranslate(&pos);
				sceGumRotateXYZ(&rot);
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,2*3,0,wall_vertices);
		}

		// Left height wall
		for ( x = 1; x <= MAP_HEIGHT/2; x++ )
		{
			sceGumLoadIdentity();
			{
				ScePspFVector3 pos = { 2*MAP_WIDTH, y*WALL_HEIGHT, x*4 };
				ScePspFVector3 rot = { 0, 90*toRads, 0 };
				sceGumTranslate(&pos);
				sceGumRotateXYZ(&rot);
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,2*3,0,wall_vertices);
		}

		// Right height wall
		for ( x = 0; x < MAP_HEIGHT/2; x++ )
		{
			sceGumLoadIdentity();
			{
				ScePspFVector3 pos = { 0, y*WALL_HEIGHT, x*4 };
				ScePspFVector3 rot = { 0, 270*toRads, 0 };
				sceGumTranslate(&pos);
				sceGumRotateXYZ(&rot);
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,2*3,0,wall_vertices);
		}
	}


	return 1;
}

void	Game_GuOptions()
{

	sceGuEnable(GU_DEPTH_TEST);
	sceGuShadeModel(GU_SMOOTH);
	sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);	
	sceGuDisable(GU_BLEND);
	sceGuEnable(GU_TEXTURE_2D);
	sceGuTexMode(GU_PSM_8888, 0, 0, 0);
	sceGuTexFunc(GU_TFX_REPLACE, GU_TCC_RGBA);
	// Modulate or Replace

	sceGuTexEnvColor(0x0);
	sceGuTexOffset(0.0f, 0.0f);
	sceGuTexScale(1.0f, 1.0f);
	sceGuTexWrap(GU_REPEAT, GU_REPEAT);
	sceGuTexFilter(GU_NEAREST, GU_NEAREST);	

	// Set the projection Matrix
	// Projection Matrix
 	sceGumMatrixMode(GU_PROJECTION);
	sceGumLoadIdentity();
	sceGumPerspective(75.0f,16.0f/9.0f,0.5f,50.0f);	

	sceGuClearColor(RGB(177,225,254));
	sceGuClearDepth(0);

}

int	Game_Render()
{

	// Start the scene
	
	sceGuStart(GU_DIRECT,list);

	// Clear the screen
	// 
//	sceGuClearColor(RGB(177,225,254));
//	sceGuClearDepth(0);	
	sceGuClear(GU_COLOR_BUFFER_BIT|GU_DEPTH_BUFFER_BIT);

	// Projection
 	sceGumMatrixMode(GU_PROJECTION);
	sceGumLoadIdentity();
	sceGumPerspective(75.0f,16.0f/9.0f,0.5f,50.0f);		
		

//	/*	

	// Camera
	sceGumMatrixMode(GU_VIEW);
	sceGumLoadIdentity();

	
	// The Camera ( shouldnt crash )
	if ( Player1.physical->alive )
	{
		// First Person View
		float camX, camY, camZ, lx, ly, lz;
		camX = Player1.physical->Object->x;
		camZ = Player1.physical->Object->y;
		camY = 0.85f + sin(Player1.bobAngle*toRads)*0.05f;
		lx = sin(-Player1.physical->YRot*toRads);
		lz = cos(-Player1.physical->YRot*toRads);
		ly = tan(-Player1.physical->XRot*toRads);
		ScePspFVector3 pos = { camX, camY, camZ };
		ScePspFVector3 look = { camX + lx, camY + ly, camZ + lz };
		ScePspFVector3 tilt = { 0.0f, 1.0f, 0.0f };
		sceGumLookAt(&pos,&look,&tilt);		
	} else {

		// Above View
		ScePspFVector3 pos = { MAP_WIDTH/2, 10.0f, MAP_HEIGHT/2 };
		ScePspFVector3 look = { MAP_WIDTH/2, 0, MAP_HEIGHT/2 };
		ScePspFVector3 tilt = { 0.0f, 1.0f, 0.0f };
		sceGumLookAt(&pos,&look,&tilt);		
	}


	// Draw all models
	sceGumMatrixMode(GU_MODEL);
	
	// The Terrain (shouldnt crash)
	drawTerrain();
	// The walls (shouldnt crash)
	drawWalls();

	// Probably Crash
	if ( Config.Outlines )
	{
		sceGuDisable(GU_DEPTH_TEST);

		// The ducks Outlines
		drawDucksOutline();
		// The Crates Outlines
		drawBoxesOutline();

		sceGuEnable(GU_DEPTH_TEST);
	}
				

	/// Probably Crash
	// The ducks
	drawDucks();
	// The crates
	drawBoxes();


	// GIVE THE DUCKS GUNS! (crash)
	drawDucksGuns();
	
	if ( Player1.physical->alive )	// (crash)
	{
		// First Person Drawing
		drawFirstPerson();
	}

//	*/
	
/*	
	// Set up for text	(crash)
	sceGuTexImage(0, 256, 128, 256, font);
	sceGuEnable(GU_BLEND);
	sceGuDisable(GU_DEPTH_TEST);


	// Draw Text
	char fpstext[32];
	sprintf(fpstext,"Current FPS: %i ",(int)fps);
	drawString( fpstext, 0, 0, RGB(0,0,255), 0);


	// Reset the Options
	sceGuDisable(GU_BLEND);
	sceGuEnable(GU_DEPTH_TEST);		
*/

	// Score Menu
	if ( pad.Buttons & PSP_CTRL_SELECT )
	{
		setFontTexture();

		drawString( "Name", 10, 1, RGB(196,196,196), 0 );
		drawString( "Kills", 300, 1, RGB(196,196,196), 0 );
		drawString( "Deaths", 400, 1, RGB(196,196,196), 0 );		

		int num = 0;
		int i;
		for ( i = 0; i < MAX_PLAYERS; i++ )
		{
			if ( nodes[i].connected )
			{	// Player	Kills	Deaths
				num++;
				int color;
				if ( Player1.player == nodes[i].player )
					color = RGB(0,255,0);
				else
					color = RGB(255,0,0);
				char text[8];
				sprintf(text, "%i", nodes[i].player->kills );
				drawString( nodes[i].player->name, 10, num*15, color, 0 );
				drawString( text, 300, num*15, color, 0 );				
				sprintf(text, "%i", nodes[i].player->deaths );				
				drawString( text, 400, num*15, color, 0 );
			}
		}

		unsetFont();
	}
				
	
	// End the scene
	sceGuFinish();
	sceGuSync(0, 0);

	// Vsync
	if ( Config.Vsync ) sceDisplayWaitVblankStart();

	// Flip the screen
	sceGuSwapBuffers();

	return 1;
}
