// Graphics.cpp - By Greg Tourville
// The messy gfx stuff
//////////////////////////

#include <pspge.h>
#include <pspgu.h>
#include <pspgum.h>
#include <pspdisplay.h>
#include <pspkernel.h>

#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <png.h>

#include "valloc.h"

// Defines
#define BUF_WIDTH (512)
#define SCR_WIDTH (480)
#define SCR_HEIGHT (272)
#define PIXEL_SIZE (4) /* change this if you change to another screenmode */
#define FRAME_SIZE (BUF_WIDTH * SCR_HEIGHT * PIXEL_SIZE)
#define ZBUF_SIZE (BUF_WIDTH * SCR_HEIGHT * 2) /* zbuffer seems to be 16-bit? */
#define RGB(r, g, b) (0xFF000000 | ((b)<<16) | ((g)<<8) | (r))


#define GU_ABGR(a,b,g,r)	(((a) << 24)|((b) << 16)|((g) << 8)|(r))
#define GU_ARGB(a,r,g,b)	GU_ABGR((a),(b),(g),(r))
#define GU_RGBA(r,g,b,a)	GU_ARGB((a),(r),(g),(b))
#define GU_COLOR(r,g,b,a)	GU_RGBA((u32)((r) * 255.0f),(u32)((g) * 255.0f),(u32)((b) * 255.0f),(u32)((a) * 255.0f))

// Globals
static unsigned int __attribute__((aligned(16))) list[262144];
void* frameBuffer;
void* doubleBuffer;
void* depthBuffer;

bool	allocated = false;


//	void* frameBuffer = (void*)0;
//	const void* doubleBuffer = (void*)0x44000;
//	const void* depthBuffer = (void*)0x110000;



/*			2D Stuff					*/

typedef u32 Color;

struct		Image
{
	int textureWidth;  // the real width of data, 2^n with n>=0
	int textureHeight;  // the real height of data, 2^n with n>=0
	int imageWidth;  // the image width
	int imageHeight;
	Color* data;
};

extern "C"
{
	void		swizzle_fast(u8* out, const u8* in, unsigned int width, unsigned int height);
	Image*		loadImage( const char* filename);
	static int 	getNextPower2(int width);	
}

struct		Texture
{
	// Variables:
	Image*		sysram;
	void*		vidram;
	int		width, height;

	// Functions:
	int		assign();
	int		load( const char* path );
	int		Texture::copyLoad( char* data, int w, int h );
	int		unload();
	int		vram();
	int		unvram();
	bool		isvram();

};

bool	Texture::isvram()
{
	if ( vidram )
		return true;
	else
		return false;
}

int		Texture::vram()
{
	
	// Move it to VRAM

	int size = sysram->textureWidth * sysram->textureHeight * sizeof(Color);
	// Allocate the space
	vidram = valloc( size ); 

	// Should check for NULL, but we want the crash to tell us we're out of vram

	u32* i;
	for ( i = (u32*)0; i < (u32*)size; i++ )
		*(u32*)((int)vidram + (int)i) = *(u32*)((int)sysram->data + (int)i);
	

	// Copy the image into VRAM
	//if (vidram)
//	{
		//memcpy( vidram, (void*)sysram->data, sizeof(vidram));
		//sceGuCopyImage(GU_PSM_8888,0,0,width,height,sysram->textureWidth,(void*)sysram->data,0,0,sysram->textureWidth,vidram);
		//memset ( sysram->data, 0, sysram->textureWidth * sysram->textureHeight * sizeof(Color) ); 
		//sceGuTexSync();
		//sceGuCopyImage(GU_PSM_8888,0,0,width,height,sysram->textureWidth,vidram,0,0,sysram->textureWidth,(void*)sysram->data);
		//vidram = NULL;
		
		//sceKernelDcacheWritebackInvalidateAll();
//	}
	
	// Change it back to absolute
	//vidram = vabsptr( vidram );
	
	return 1;
}

int		Texture::unvram()
{
	// Free it from VRAM
	if ( vidram )
	{
		vfree(vidram);
		vidram = NULL;
		return 1;
	} else {
		return 0;
	}
}

int		Texture::copyLoad( char* data, int w, int h )
{
	// Resolutions
	sysram = (Image*)malloc(sizeof(Image));	
	width = w;
	height = h;
	sysram->imageWidth = w;
	sysram->imageHeight = h;
	sysram->textureWidth = getNextPower2(w);
	sysram->textureHeight = getNextPower2(h);
	
	// Make the new image
	sysram->data = (Color*) memalign(16, sysram->textureWidth * sysram->textureHeight * sizeof(Color));

	// Copy the data over
	memcpy( sysram->data, data, w*h*sizeof(Color) );

	// Swizzle it
//	u8* swizzled;
//	swizzled = (u8*)memalign(16,sysram->textureWidth*sysram->textureHeight*sizeof(Color));
//	swizzle_fast(swizzled, (u8*)sysram->data, sysram->textureWidth * 4, sysram->textureHeight);
//	memcpy((void*)sysram->data, (void*)swizzled, sysram->textureWidth*sysram->textureHeight*sizeof(Color));
//	free((void*)swizzled);
	
	vidram = NULL;

	return 1;	
}

// Texture Functions:
int		Texture::load( const char* path )
{
	// Load the image
	sysram = loadImage( path );
	width = sysram->imageWidth;
	height = sysram->imageHeight;

	// Swizzle it
	
	u8* swizzled;
	swizzled = (u8*)memalign(16,sysram->textureWidth*sysram->textureHeight*sizeof(Color));
	swizzle_fast(swizzled, (u8*)sysram->data, sysram->textureWidth * 4, sysram->textureHeight);
	memcpy((void*)sysram->data, (void*)swizzled, sysram->textureWidth*sysram->textureHeight*sizeof(Color));
	free((void*)swizzled);
	
	vidram = NULL;

	// done

	return 1;
}

int		Texture::unload()
{
	// Free the image
	free((void*)sysram->data);
	// Free the image*
	free((void*)sysram);

	// Check for vram
	if (vidram != NULL)
		vfree(vidram);

	return 1;
}

int		Texture::assign()
{
	if ( vidram == NULL )
	{
		// Swizzled
		sceGuTexMode(GU_PSM_8888,0,0,true);
		sceGuTexImage(0,width,height,sysram->textureWidth,sysram->data);
		sceGuTexFunc(GU_TFX_REPLACE,GU_TCC_RGBA);
//		sceGuTexFilter(GU_LINEAR_MIPMAP_LINEAR,GU_LINEAR);
		sceGuTexFilter(GU_LINEAR,GU_LINEAR);		
		sceGuTexScale(1.0f,1.0f);
		sceGuTexOffset(0.0f,0.0f);
	} else {
		// In VRAM
		sceGuTexMode(GU_PSM_8888,0,0,true);
		sceGuTexImage(0,width,height,sysram->textureWidth,vidram);
		//sceGuTexImage(0,512,512,512, (void*)(((0x40000000 | 0x04000000) + (512*280*4)*2) + (512*280*4)));
		sceGuTexFunc(GU_TFX_REPLACE,GU_TCC_RGBA);
		// Modulate for color (i think)
		sceGuTexFilter(GU_LINEAR,GU_LINEAR);		
		sceGuTexScale(1.0f,1.0f);
		sceGuTexOffset(0.0f,0.0f);
	}


	return 1;
}


extern "C"
{

	void user_warning_fn(png_structp png_ptr, png_const_charp warning_msg)
	{
	}

	static int getNextPower2(int width)
	{
		int b = width;
		int n;
		for (n = 0; b != 0; n++) b >>= 1;
		b = 1 << n;
		if (b == 2 * width) b >>= 1;
		return b;
	}

	Image* loadImage(const char* filename)
	{
		png_structp png_ptr;
		png_infop info_ptr;
		unsigned int sig_read = 0;
		png_uint_32 width, height;
		int bit_depth, color_type, interlace_type, x, y;
		u32* line;
		FILE *fp;
		Image* image = (Image*) malloc(sizeof(Image));
		if (!image) return NULL;

		if ((fp = fopen(filename, "rb")) == NULL) return NULL;
		png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
		if (png_ptr == NULL) {
			free(image);
			fclose(fp);
			return NULL;;
		}
		png_set_error_fn(png_ptr, (png_voidp) NULL, (png_error_ptr) NULL, user_warning_fn);
		info_ptr = png_create_info_struct(png_ptr);
		if (info_ptr == NULL) {
			free(image);
			fclose(fp);
			png_destroy_read_struct(&png_ptr, png_infopp_NULL, png_infopp_NULL);
			return NULL;
		}
		png_init_io(png_ptr, fp);
		png_set_sig_bytes(png_ptr, sig_read);
		png_read_info(png_ptr, info_ptr);
		png_get_IHDR(png_ptr, info_ptr, &width, &height, &bit_depth, &color_type, &interlace_type, int_p_NULL, int_p_NULL);
		if (width > 512 || height > 512) {
			free(image);
			fclose(fp);
			png_destroy_read_struct(&png_ptr, png_infopp_NULL, png_infopp_NULL);
			return NULL;
		}
		image->imageWidth = width;
		image->imageHeight = height;
		image->textureWidth = getNextPower2(width);
		image->textureHeight = getNextPower2(height);
		png_set_strip_16(png_ptr);
		png_set_packing(png_ptr);
		if (color_type == PNG_COLOR_TYPE_PALETTE) png_set_palette_to_rgb(png_ptr);
		if (color_type == PNG_COLOR_TYPE_GRAY && bit_depth < 8) png_set_gray_1_2_4_to_8(png_ptr);
		if (png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS)) png_set_tRNS_to_alpha(png_ptr);
		png_set_filler(png_ptr, 0xff, PNG_FILLER_AFTER);
		image->data = (Color*) memalign(16, image->textureWidth * image->textureHeight * sizeof(Color));
		if (!image->data) {
			free(image);
			fclose(fp);
			png_destroy_read_struct(&png_ptr, png_infopp_NULL, png_infopp_NULL);
			return NULL;
		}
		line = (u32*) malloc(width * 4);
		if (!line) {
			free(image->data);
			free(image);
			fclose(fp);
			png_destroy_read_struct(&png_ptr, png_infopp_NULL, png_infopp_NULL);
			return NULL;
		}
		for (y = 0; y < height; y++) {
			png_read_row(png_ptr, (u8*) line, png_bytep_NULL);
			for (x = 0; x < width; x++) {
				u32 color = line[x];
				image->data[x + y * image->textureWidth] =  color;
			}
		}
		free(line);
		png_read_end(png_ptr, info_ptr);
		png_destroy_read_struct(&png_ptr, &info_ptr, png_infopp_NULL);
		fclose(fp);
		return image;
	}

}

extern "C"
{
	void swizzle_fast(u8* out, const u8* in, unsigned int width, unsigned int height)
	{
	   unsigned int blockx, blocky;
	   unsigned int j;
	 
	   unsigned int width_blocks = (width / 16);
	   unsigned int height_blocks = (height / 8);
	 
	   unsigned int src_pitch = (width-16)/4;
	   unsigned int src_row = width * 8;
	 
	   const u8* ysrc = in;
	   u32* dst = (u32*)out;
	 
	   for (blocky = 0; blocky < height_blocks; ++blocky)
	   {
		  const u8* xsrc = ysrc;
		  for (blockx = 0; blockx < width_blocks; ++blockx)
		  {
			 const u32* src = (u32*)xsrc;
			 for (j = 0; j < 8; ++j)
			 {
				*(dst++) = *(src++);
				*(dst++) = *(src++);
				*(dst++) = *(src++);
				*(dst++) = *(src++);
				src += src_pitch;
			 }
			 xsrc += 16;
		 }
		 ysrc += src_row;
	   }
	}
}


void savePngImage(const char* filename, Color* data, int width, int height, int lineSize, int saveAlpha)
{
	png_structp png_ptr;
	png_infop info_ptr;
	FILE* fp;
	int i, x, y;
	u8* line;
	
	if ((fp = fopen(filename, "wb")) == NULL) return;
	png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	if (!png_ptr) return;
	info_ptr = png_create_info_struct(png_ptr);
	if (!info_ptr) {
		png_destroy_write_struct(&png_ptr, (png_infopp)NULL);
		return;
	}
	png_init_io(png_ptr, fp);
	png_set_IHDR(png_ptr, info_ptr, width, height, 8,
		saveAlpha ? PNG_COLOR_TYPE_RGBA : PNG_COLOR_TYPE_RGB,
		PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
	png_write_info(png_ptr, info_ptr);
	line = (u8*) malloc(width * (saveAlpha ? 4 : 3));
	for (y = 0; y < height; y++) {
		for (i = 0, x = 0; x < width; x++) {
			Color color = data[x + y * lineSize];
			u8 r = color & 0xff; 
			u8 g = (color >> 8) & 0xff;
			u8 b = (color >> 16) & 0xff;
			u8 a = saveAlpha ? (color >> 24) & 0xff : 0xff;
			line[i++] = r;
			line[i++] = g;
			line[i++] = b;
			if (saveAlpha) line[i++] = a;
		}
		png_write_row(png_ptr, line);
	}
	free(line);
	png_write_end(png_ptr, info_ptr);
	png_destroy_write_struct(&png_ptr, (png_infopp)NULL);
	fclose(fp);
}


void saveJpegImage(const char* filename, Color* data, int width, int height, int lineSize)
{
	FILE* outFile = fopen(filename, "wb");
	if (!outFile) return;
	struct jpeg_error_mgr jerr;
	struct jpeg_compress_struct cinfo;
	cinfo.err = jpeg_std_error(&jerr);
	jpeg_create_compress(&cinfo);
	jpeg_stdio_dest(&cinfo, outFile);
	cinfo.image_width = width;
	cinfo.image_height = height;
	cinfo.input_components = 3;
	cinfo.in_color_space = JCS_RGB;
	jpeg_set_defaults(&cinfo);
	jpeg_set_quality(&cinfo, 100, TRUE);
	jpeg_start_compress(&cinfo, TRUE);
	u8* row = (u8*) malloc(width * 3);
	if (!row) return;
	for (int y = 0; y < height; y++) {
		u8* rowPointer = row;
		for (int x = 0; x < width; x++) {
			Color c = data[x + cinfo.next_scanline * lineSize];
			*(rowPointer++) = c & 0xff;
			*(rowPointer++) = (c >> 8) & 0xff;
			*(rowPointer++) = (c >> 16) & 0xff;
		}
		jpeg_write_scanlines(&cinfo, &row, 1);
	}
	jpeg_finish_compress(&cinfo);
	jpeg_destroy_compress(&cinfo);
	fclose(outFile);
	free(row);
}



/*			3D Stuff					*/

// Structs
struct Vertex
{
	float u, v;
	unsigned int color;
	float x,y,z;
};

typedef struct _point2 {
	double x,y;
} Point2;

typedef struct _point3 {
	double x,y,z;
} Point3;


// Functions:

int setupGu( ) {

	// Don't Allocate more than once with multiple calls per App
	if (!allocated)
	{
		frameBuffer = vrelptr(valloc( FRAME_SIZE ));
		doubleBuffer = vrelptr(valloc( FRAME_SIZE ));
		depthBuffer = vrelptr(valloc( ZBUF_SIZE ));
	}

	// Init the Gu
	sceGuInit();

	// Set up gu
	sceGuStart(GU_DIRECT,list);	

	// Start the GU frame
	sceGuDrawBuffer(GU_PSM_8888,frameBuffer,BUF_WIDTH);		// Set the frameBuffer as the draw buffer
	sceGuDispBuffer(SCR_WIDTH,SCR_HEIGHT,(void*)doubleBuffer,BUF_WIDTH);	
	sceGuDepthBuffer((void*)depthBuffer,BUF_WIDTH); // depthBuffer
	// Set our default options
	sceGuOffset(2048 - (SCR_WIDTH/2),2048 - (SCR_HEIGHT/2));	
	sceGuViewport(2048,2048,SCR_WIDTH,SCR_HEIGHT);			
	sceGuDepthRange(65535,0);					
	sceGuScissor(0,0,SCR_WIDTH,SCR_HEIGHT);
	sceGuEnable(GU_SCISSOR_TEST);
	sceGuDepthFunc(GU_GEQUAL);
	sceGuEnable(GU_DEPTH_TEST);
	sceGuFrontFace(GU_CCW);			// Counter Clockwise (Milkshape)
	sceGuShadeModel(GU_SMOOTH);	
	sceGuEnable(GU_CULL_FACE);
	sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);	
	sceGuDisable(GU_BLEND);			// Blending disabled by default	
	sceGuEnable(GU_TEXTURE_2D);		// Textures Enabled by default
	sceGuEnable(GU_CLIP_PLANES);
	// Texture Options
	sceGuTexMode(GU_PSM_8888,0,0,true);
	sceGuTexFunc(GU_TFX_REPLACE,GU_TCC_RGBA);	// Replace or Modulate
	sceGuTexFilter(GU_LINEAR,GU_LINEAR);		
	sceGuTexScale(1.0f,1.0f);
	sceGuTexOffset(0.0f,0.0f);	

	// Set the Framebuffer to the screen	
	sceGuFinish();							
	sceGuSync(0,0);							
	sceDisplayWaitVblankStart();
	sceGuDisplay(GU_TRUE);		
	
	// Return Success
	return 1;
}

int	shutdownGu()
{
	// Term the Gu
	sceGuTerm();

	// Return Success
	return 1;
}
