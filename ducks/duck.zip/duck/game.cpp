
int	initPhysics()
{
	World = new Physics;
	World->LEFT_X = 0;
	World->RIGHT_X = 20;
	World->UPPER_Y = 0;
	World->LOWER_Y = 40;

	World->FRICTION = 7.0f;
	World->GRAVITY = 0.0f;
	World->GRAVITY_ANGLE = 0.0f;
	World->LOSS_OF_ENERGY = 0.5f;

	World->SectionWidth = 30;
	World->SectionHeight = 50;
	World->SectionsX = 1;
	World->SectionsY = 1;
		
	World->Initialize();

	// Circle  "Kinds":
	// Kind 0 = Box, 1 = Player1, 2 = Net Player
	
	return 1;
}


int	shutdownPhysics()
{
	delete World;
	return 1;
}


int gameBrowser( int numGames, ShortInfo* Games )
{
	int choice = -1;
	SceCtrlData pad, old;	
	float c = 0;	// Sin rotations for the brightness

	bool done = false;
	while( !done )
	{
		c += 0.01f;
		
		if ( Config.DebugMode == false )
		{
			sceGuStart(GU_DIRECT,list);
		
			// Clear the Screen
			sceGuClearColor(RGB( (int)(50 + (sin(c)*30)) , (int)(35 + (sin(c)*30)), (int)(30 + (sin(c)*30) )));
			sceGuClearDepth(0);
			sceGuClear(GU_COLOR_BUFFER_BIT|GU_DEPTH_BUFFER_BIT);		
		}

		// Get Input
		old = pad;
		sceCtrlReadBufferPositive(&pad, 1);

		if ( (pad.Buttons & PSP_CTRL_UP) && !(old.Buttons & PSP_CTRL_UP) && choice > -1 )
			choice--;

		if ( (pad.Buttons & PSP_CTRL_DOWN) && !(old.Buttons & PSP_CTRL_DOWN) && choice < numGames )
			choice++;

		if ( pad.Buttons & PSP_CTRL_CROSS ) done = true;		
		
		// hmm cant be yellow cause it'll ruin atmosphere (music or ambient sound here TODO)
		
/*
		sceGumMatrixMode(GU_VIEW);
		sceGumLoadIdentity();

		sceGumMatrixMode(GU_MODEL);
		sceGumLoadIdentity();
		{
			ScePspFVector3 pos = { -5.0f, 1.0f, 0 };
			ScePspFVector3 rot = { 0, c/2, 0 };
			ScePspFVector3 scale = { 1.0f, 1.0f, 1.0f };
			sceGumTranslate(&pos);
			sceGumRotateXYZ(&rot);
			sceGumScale(&scale);
		}

		duckTex.assign();
		sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,DUCK_TRIANGLES*3,0,duckModel);
		*/

		// Only Draw to the screen if we aren't in the special debug mode
		// (So we can read all the Printf's)
		if ( Config.DebugMode == false )
		{		
		
			
//			fontTex.assign();
			setFontTexture();

			drawString("QUAK ARENA", 0, 0, RGB(255,0,0), 0);
			drawString("Server Browser", 110, 0, RGB(200,200,200), 0);
		
			// Draw the text (10 apart vertically)	//
			drawString("New Server", 50, 50, RGB( (int)(150 - sin(c)*30) , (int)(135 - sin(c)*30), (int)(130 - sin(c)*30) ), 0);
			int i;
			for ( i = 0; i < numGames; i++ )
			{
				// Game Name
				drawString(Games[i].name, 50, 50 + (i+1)*15, RGB( (int)(150 - sin(c)*30) , (int)(135 - sin(c)*30), (int)(130 - sin(c)*30) ), 0);
				// Num Players
				char text[32];
				sprintf(text,"%i / %i Players", Games[i].curPlayers, Games[i].maxPlayers);
				drawString(text, 300, 50+(i+1)*15, RGB( 150, 150, 150 ), 0 );
			}
			drawString("Quit", 50, 50+(numGames+1)*15, RGB( (int)(150 - sin(c)*30) , (int)(135 - sin(c)*30), (int)(130 - sin(c)*30) ), 0);		


			// Draw the selected text				//
			if ( choice == -1 )
			{	// New Server
				drawString("New Server", 48, 48, RGB( (int)(220 - sin(c*8)*30) , (int)(220 - sin(c*8)*30), (int)(220 - sin(c*8)*30) ), 0);	
			} else if ( choice == numGames ) {
				// Quit
				drawString("Quit", 48, 48 + (numGames+1)*15, RGB( (int)(220 - sin(c*8)*30) , (int)(220 - sin(c*8)*30), (int)(220 - sin(c*8)*30) ), 0);	
			} else {
				// A Server
				drawString(Games[choice].name, 48, 48 + (choice+1)*15, RGB( (int)(220 - sin(c*8)*30) , (int)(220 - sin(c*8)*30), (int)(220 - sin(c*8)*30) ), 0);	
			}
		
		// Flip

			sceGuFinish();
			sceGuSync(0, 0);		
			if ( Config.Vsync ) sceDisplayWaitVblankStart();		
			sceGuSwapBuffers();
		}

	}

	if ( !Config.DebugMode ) unsetFont();

	if ( choice == -1 ) return -1;
	if ( choice == numGames ) return 0;
	return Games[choice].id;
}
	



int	game()
{
	if ( !Config.DebugMode ) Game_GuOptions();
	printf( "In game \n");

	// Set the base timer
	double	tickRes = sceRtcGetTickResolution();
	sceRtcGetCurrentTick( &thistime );

	Player1.bobAngle = 0;

//	Reset GU so it doesn't Crash

/*	shutdownGu();
	if (!GraphicsLoaded) 
		initGraphics();
	else
		setupGu();
*/

	for(;;)
	{
		if ( Config.DebugMode )	printf("Main Loop Iteration \n");

		// Update Timing
		oldtime = thistime;
		sceRtcGetCurrentTick( &thistime );
		dt = (thistime - oldtime) / tickRes;
		fps = 1 / dt;

		if ( Config.DebugMode )	printf("Check Respawn \n");		
		// Check for respawn
		if ( !Player1.physical->alive )
		{
			Player1.respawnTime -= dt;
			if ( Player1.respawnTime <= 0.0f )
			{
				// Spawn
				Player1.physical->alive = true;

				// Spawn the player
				Player1.physical->Object = new ColCircle;
				Player1.physical->Object->kind = 1;
				Player1.physical->Object->xsp = 0;
				Player1.physical->Object->ysp = 0;
				Player1.physical->Object->size = PLAYER_SIZE;
				Player1.physical->Object->x = rand()%MAP_WIDTH;
				Player1.physical->Object->y = rand()%MAP_HEIGHT;

				// Add the ColCircle to the Physics World
				Player1.physical->ObjectIndex = World->AddCircle( Player1.physical->Object );
				
				if ( Config.DebugMode )	printf("You respawned \n");				
			}
		}

		if ( Config.DebugMode )	printf("Input... \n");
		// Get Input
		if ( !Game_Input() )
		{	
			break;	
		}

		if ( Config.DebugMode )	printf("Network... \n");		
		// Update Network
		Game_Network();

		if ( Config.DebugMode )	printf("Physics... \n");		
		// Update Physics
		World->GlobalUpdate( dt );		
		
		// Render the scene
		if ( !Config.DebugMode )
		{
			Game_Render();
		}

	}


	// User is exiting, give everyone the disconnect signal
	sprintf( outbuf, "BYEBYE" );
	SendMessage();
	int i;
	for ( i = 0; i < MAX_PLAYERS; i++ )
	{
		if ( nodes[i].connected && strcmp(nodes[i].ip, Player1.IP) )
		{
			Socket_close( nodes[i].socket );
			nodes[i].socket = NULL;
		}
		nodes[i].connected = false;
	}
		
	// Connect to master server and ask to be removed from list
	// 	


	return 1;
}
