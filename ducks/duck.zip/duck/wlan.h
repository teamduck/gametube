// WLAN - Original code from Luaplayer
// Based off of PSPpet's work
// Converted By Greg Tourville

#include <pspnet_apctl.h>

#define MAX_PICK 5


struct Pick
{
	int index;
	char name[64];
};

extern Pick picks[MAX_PICK];

struct sockaddr_in {
        unsigned char sin_size; // size, not used
        unsigned char sin_family; // usually AF_INET
        unsigned short sin_port; // use htons()
        u32 sin_addr;
        char sin_zero[8];
};

#define SOCKET int

typedef struct
{
	SOCKET sock;
	struct sockaddr_in addrTo;
	bool serverSocket;
} Socket;


int Wlan_init();					// Sets up WLAN
int Wlan_term();					// Ends WLAN
int Wlan_getConnectionConfigs();			// Stores in picks[]
int Wlan_useConnectionConfig(int connectionConfig);	// Connects to connection#
char* Wlan_getIPAddress();				// Get the PSP's IP
int Socket_free(Socket* socket);			// Free a socket
Socket* Socket_connect(const char* host, int port);	// Connect to Host::port
int Socket_isConnected(Socket* socket);			// Is this socket connected
Socket* Socket_createServerSocket(int port);		// Create a server socket
Socket* Socket_accept(Socket* socket);			// Accept incoming connections on a server socket
int Socket_recv(Socket* socket, void* buffer, size_t bytes); // Recieves data from a socket
int Socket_send(Socket* socket, const void* buffer, size_t bytes); // Sends data from a socket
int Socket_close(Socket* socket);			// Closes a socket
char* Socket_toString(Socket* socket);			// Returns socket ip as string?

