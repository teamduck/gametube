#ifndef __CONF_H__
#define __CONF_H__

typedef struct
{

	char name[64];
	char server[64];
	int  respawn;
	int red;
	int green;
	int blue;

} CONFIGFILE;

void read_config(const char *file, CONFIGFILE *config);

#endif 

/* Example
//////////
CONFIGFILE
//////////

// Set a configfile
CONFIGFILE config;

// Whenever you want to read from the config file
read_config("ms0:/config.txt", &config);

// Based on this example, In that config file it's going to look for
name = "Something";
// and then return "Something" to config->name
// so config->name is going to hold the char Something

*/
