// ModelLoad.cpp //
// ///////////////


// Include Models
#include "de_duck3.h"
#include "crate.h"
#include "gun.h"

struct Vertex __attribute__((aligned(16))) grass_vertices[2*3] =
{
	{1, 0, RGB(0,0,0), 2, 0, 0},
	{0, 0, RGB(0,0,0), 0, 0, 0},
	{1, 1, RGB(0,0,0), 2, 0, 2},

	{0, 1, RGB(0,0,0), 0, 0, 2},
	{1, 1, RGB(0,0,0), 2, 0, 2},
	{0, 0, RGB(0,0,0), 0, 0, 0},
};

struct Vertex __attribute__((aligned(16))) wall_vertices[2*3] =
{
	{0.5f, 0, RGB(0,0,0), 4, 0, 0},
	{0, 0, RGB(0,0,0), 0, 0, 0},
	{0.5f, 0.5f, RGB(0,0,0), 4, 2, 0},

	{0, 0.5f, RGB(0,0,0), 0, 2, 0},
	{0.5f, 0.5f, RGB(0,0,0), 4, 2, 0},
	{0, 0, RGB(0,0,0), 0, 0, 0},
};

Vertex __attribute__((aligned(16))) duckModel[DUCK_TRIANGLES*3];
Vertex __attribute__((aligned(16))) crateModel[CRATE_TRIANGLES*3];
Vertex __attribute__((aligned(16))) gunModel[GUN_TRIANGLES*3];

int	convertModels()
{
	int i;

	// Duck Model
	for( i=0; i < DUCK_TRIANGLES * 3; i++ )
	{
		duckModel[i].u = (float)Duck_uv[Duck_vidx[i]].x;
		duckModel[i].v = (float)Duck_uv[Duck_vidx[i]].y;
		duckModel[i].color = RGB(0,0,0);
		duckModel[i].x = (float)Duck_vertex[Duck_vidx[i]].x;
		duckModel[i].y = (float)Duck_vertex[Duck_vidx[i]].y;
		duckModel[i].z = (float)Duck_vertex[Duck_vidx[i]].z;
	}

	// Crate Model
	for( i=0; i < CRATE_TRIANGLES * 3; i++ )
	{
		crateModel[i].u = (float)Crate_uv[Crate_vidx[i]].x;
		crateModel[i].v = (float)Crate_uv[Crate_vidx[i]].y;
		crateModel[i].color = RGB(0,0,0);
		crateModel[i].x = (float)Crate_vertex[Crate_vidx[i]].x;
		crateModel[i].y = (float)Crate_vertex[Crate_vidx[i]].y;
		crateModel[i].z = (float)Crate_vertex[Crate_vidx[i]].z;
	}

	// Gun Model
	for( i=0; i < GUN_TRIANGLES * 3; i++ )
	{
		gunModel[i].u = (float)Gun_uv[Gun_vidx[i]].x;
		gunModel[i].v = (float)Gun_uv[Gun_vidx[i]].y;
		gunModel[i].color = RGB(0,0,0);
		gunModel[i].x = (float)Gun_vertex[Gun_vidx[i]].x;
		gunModel[i].y = (float)Gun_vertex[Gun_vidx[i]].y;
		gunModel[i].z = (float)Gun_vertex[Gun_vidx[i]].z;
	}	


	// Other Models

	return 1;
}


