/////////////////////////////////
// Test
////
// August 8th, 2006
/////////////////////////////////
// Coder: Slasher & Xigency
/////////////////////////////////



///////////// INCLUDES //////////////

#include <pspkernel.h>
#include <pspdisplay.h>
#include <pspdebug.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <pspctrl.h>

// 3D Stuff
#include <pspge.h>
#include <pspgu.h>
#include <pspgum.h>

// Message Box
#include <psputility.h>

// FPS
#include <psprtc.h>

// GFX stuff
#include "graphics.h"
#include "valloc.h"

#include "physics.h"

// Model loading
#include "models/modelLoad.cpp"


// Module info
PSP_MODULE_INFO("Test", 0, 1, 1);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);



//////////// DEFINES ///////////////

#define printf			pspDebugScreenPrintf 

#define OUTLINES

#define	THRESHHOLD		48
#define	SENSITIVITY		1.0f
#define MOVE_SPEED		25.0f
#define	BOB_SPEED		720.0f

#define DUCK_SPEED		-6.0f
#define JUMP_SPEED		8.0f

#define	MAP_HEIGHT		20
#define	MAP_WIDTH		10

#define WALL_HEIGHT		1

// Gu Defines
//#define toRads (3.1415)/180

#define RGB(r, g, b) (0xFF000000 | ((b)<<16) | ((g)<<8) | (r))



/////////// STRUCTS ////////////////

struct Vertex __attribute__((aligned(16))) grass_vertices[2*3] =
{
	{1, 0, RGB(0,0,0), 2, 0, 0},
	{0, 0, RGB(0,0,0), 0, 0, 0},
	{1, 1, RGB(0,0,0), 2, 0, 2},

	{0, 1, RGB(0,0,0), 0, 0, 2},
	{1, 1, RGB(0,0,0), 2, 0, 2},
	{0, 0, RGB(0,0,0), 0, 0, 0},
};

struct Vertex __attribute__((aligned(16))) wall_vertices[2*3] =
{
	{0.5f, 0, RGB(0,0,0), 4, 0, 0},
	{0, 0, RGB(0,0,0), 0, 0, 0},
	{0.5f, 0.5f, RGB(0,0,0), 4, 2, 0},

	{0, 0.5f, RGB(0,0,0), 0, 2, 0},
	{0.5f, 0.5f, RGB(0,0,0), 4, 2, 0},
	{0, 0, RGB(0,0,0), 0, 0, 0},
};


//////////// GLOBALS ///////////////

// Game Variables
float	camX, camY, camZ;
float	camXRot, camYRot, camZRot;

float	camRot = 0;
float	camZoom = 0;
float	camRotSpeed = 0;

ColCircle*	DuckObject;

// Textures
Texture duckTex;
Texture duckOutlineTex;

Texture crateTex;
Texture crateOutlineTex;

Texture gunTex;
Texture gunOutlineTex;

Texture brickTex;
Texture skyTex;
Texture grassTex;

float	bobAngle = 0.0f;


#define		MAX_DUCKS	50

struct Duck
{
	ColCircle*	Object;
	float		RotY;
	float		RotSpeed;
	float		JumpDelay;
};

Duck*	Ducks[MAX_DUCKS];

#define		MAX_BOXES	30

struct Box
{
	ColCircle*	Object;
};

Box*	Boxes[MAX_BOXES];


#define		MAX_BRICKS	15

struct Brick
{
	ColWall*	Object;
	Vertex*		Render;
};

Brick*	Bricks[MAX_BRICKS];
	
float	curr_ms = 1.0f;


////////// FUNCTIONS ///////////////

/* Exit callback */
int exit_callback(int arg1, int arg2, void *common)
{
	sceKernelExitGame();
	return 0;
}

/* Callback thread */
int CallbackThread(SceSize args, void *argp)
{
	int cbid;
	cbid = sceKernelCreateCallback("Exit Callback", exit_callback, NULL);
	sceKernelRegisterExitCallback(cbid);
	sceKernelSleepThreadCB();
	return 0;
}

/* Sets up the callback thread and returns its thread id */
int SetupCallbacks(void)
{
	int thid = 0;
	thid = sceKernelCreateThread("update_thread", CallbackThread, 0x11, 0xFA0, 0, 0);
	if(thid >= 0) sceKernelStartThread(thid, 0, 0);
	return thid;
}


int	initGraphics()
{
	setupGu();
	convertModels();

	// Projection Matrix
 	sceGumMatrixMode(GU_PROJECTION);
	sceGumLoadIdentity();
	sceGumPerspective(75.0f,16.0f/9.0f,0.5f,50.0f);
	//                fov, aspect,    near, far

	// Load textures
	grassTex.load("resources/grass.png");
	duckTex.load("resources/ducktex.png");
	crateTex.load("resources/crate.png");
	brickTex.load("resources/brick.png");
	gunTex.load("resources/guntex.png");
	skyTex.load("resources/sky.png");
	duckOutlineTex.load("resources/duckoutline.png");
	crateOutlineTex.load("resources/crateoutline.png");
	gunOutlineTex.load("resources/gunoutline.png");
	
	
	// Vram them
	
	// Always on the screen
	skyTex.vram();
	gunTex.vram();
	
	// Sometimes on the screen
	grassTex.vram();
	duckTex.vram();
	brickTex.vram();
	crateTex.vram();

	// Outlines
	duckOutlineTex.vram();
	crateOutlineTex.vram();	
	gunOutlineTex.vram();
	
//	sceGuShadeModel(GU_FLAT);	
	
	return 1;
}


int drawFirstPerson()
{

	// First Person Drawing
	
	// Set to First Person
	sceGumMatrixMode(GU_VIEW);
	sceGumLoadIdentity();

	// No Depth Testing
	sceGuDisable(GU_DEPTH_TEST);
	
	sceGumMatrixMode(GU_MODEL);
	
	
	/*		The Gun		*/

	sceGumLoadIdentity();
	{
		ScePspFVector3 rot = { 0.0f, 180*toRads, 0.0f };
		ScePspFVector3 pos = { 0.0f, -0.32f+sin((bobAngle)*toRads)*0.02f, 0.32f };
		sceGumTranslate(&pos);	
		sceGumRotateXYZ(&rot);
	}

	gunTex.assign();
	sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,GUN_TRIANGLES*3,0,gunModel);



	// Turn Depth Testing Back On
	sceGuEnable(GU_DEPTH_TEST);	

	return 1;
}

int drawTerrain()
{
	int x, y;
	grassTex.assign();
	
	for (y = 0; y < MAP_HEIGHT; y++)
	{
		for (x = 0; x < MAP_WIDTH; x++)
		{
			sceGumLoadIdentity();
			{
				ScePspFVector3 pos = { x*2, 0, y*2 };
				ScePspFVector3 rot = { 0, 0, 0 };
				sceGumTranslate(&pos);
				sceGumRotateXYZ(&rot);
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,2*3,0,grass_vertices);
		}
	}

	return 1;
}

int drawDucks()
{
	int i;

	// Inner
	duckTex.assign();	

	for ( i = 0; i < MAX_DUCKS; i++ )
	{
		if ( Ducks[i] != NULL )
		{

			sceGumLoadIdentity();
			{
				ScePspFVector3 pos = { Ducks[i]->Object->x, 0, Ducks[i]->Object->y };
				ScePspFVector3 rot = { 0, Ducks[i]->RotY*toRads, 0 };
				ScePspFVector3 scale = { 1.0f, 1.0f, 1.0f };
				sceGumTranslate(&pos);
				sceGumRotateXYZ(&rot);
				sceGumScale(&scale);
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,DUCK_TRIANGLES*3,0,duckModel);
		}
	}

	return 1;
}

int	drawDucksGuns()
{
	int i;

	gunTex.assign();

	for ( i = 0; i < MAX_DUCKS; i++ )
	{
		if ( Ducks[i] != NULL )
		{
			sceGumLoadIdentity();
			{
				ScePspFVector3 rot = { 0.0f, (Ducks[i]->RotY+180)*toRads, 0.0f };
				ScePspFVector3 scale = { 0.4f, 0.4f, 0.4f };
				ScePspFVector3 pos = { Ducks[i]->Object->x, 0.5f, Ducks[i]->Object->y };
				sceGumTranslate(&pos);	
				sceGumRotateXYZ(&rot);
				sceGumScale(&scale);
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,GUN_TRIANGLES*3,0,gunModel);
		}
	}

	return 1;
}


int	drawDucksOutline()
{
	int i;

	// Outline
	duckOutlineTex.assign();	
	
	for ( i = 0; i < MAX_DUCKS; i++ )
	{
		if ( Ducks[i] != NULL )
		{
			sceGumLoadIdentity();
			{
				ScePspFVector3 pos1 = { 0, -0.25f, 0 };
				ScePspFVector3 pos = { Ducks[i]->Object->x, 0.25f, Ducks[i]->Object->y };
				ScePspFVector3 rot = { 0, Ducks[i]->RotY*toRads, 0 };
				ScePspFVector3 scale = { 1.05f, 1.05f, 1.05f };
				sceGumTranslate(&pos);
				sceGumRotateXYZ(&rot);
				sceGumScale(&scale);
				sceGumTranslate(&pos1);
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,DUCK_TRIANGLES*3,0,duckModel);
		}
	}	


	return 1;
}

int	drawBoxes()
{
	int i;
	crateTex.assign();
	
	for ( i = 0; i < MAX_BOXES; i++ )
	{
		if ( Boxes[i] != NULL )
		{


			sceGumLoadIdentity();
			{
				ScePspFVector3 pos = { Boxes[i]->Object->x, 0, Boxes[i]->Object->y };
				ScePspFVector3 rot = { 0, 0, 0 };
				ScePspFVector3 scale = { 1.0f, 1.0f, 1.0f };
				sceGumTranslate(&pos);
				sceGumRotateXYZ(&rot);
				sceGumScale(&scale);
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,CRATE_TRIANGLES*3,0,crateModel);
		}
	}

	return 1;
}

int	drawBoxesOutline()
{
	int i;
	crateOutlineTex.assign();
	
	for ( i = 0; i < MAX_BOXES; i++ )
	{
		if ( Boxes[i] != NULL )
		{


			sceGumLoadIdentity();
			{
				ScePspFVector3 pos1 = { 0.0f, -1.0f, 0.0f };
				ScePspFVector3 pos = { Boxes[i]->Object->x, 1.0f, Boxes[i]->Object->y };
				ScePspFVector3 rot = { 0, 0, 0 };
				ScePspFVector3 scale = { 1.05f, 1.05f, 1.05f };
				sceGumTranslate(&pos);
				sceGumRotateXYZ(&rot);
				sceGumScale(&scale);
				sceGumTranslate(&pos1);				
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,CRATE_TRIANGLES*3,0,crateModel);
		}
	}

	return 1;
}

int drawWalls()
{
	int x, y;
	
	brickTex.assign();
//	sceGuTexFilter(GU_NEAREST_MIPMAP_NEAREST,GU_NEAREST_MIPMAP_NEAREST);

	for ( y = 0; y < WALL_HEIGHT; y++ )
	{
		// Closest width wall
		for ( x = 1; x <= MAP_WIDTH/2; x++ )
		{
			sceGumLoadIdentity();
			{
				ScePspFVector3 pos = { x*4, y*WALL_HEIGHT, 0 };
				ScePspFVector3 rot = { 0, 180*toRads, 0 };
				sceGumTranslate(&pos);
				sceGumRotateXYZ(&rot);
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,2*3,0,wall_vertices);
		}

		// Furthest width wall
		for ( x = 0; x < MAP_WIDTH/2; x++ )
		{
			sceGumLoadIdentity();
			{
				ScePspFVector3 pos = { x*4, y*WALL_HEIGHT, 2*MAP_HEIGHT };
				ScePspFVector3 rot = { 0, 0, 0 };
				sceGumTranslate(&pos);
				sceGumRotateXYZ(&rot);
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,2*3,0,wall_vertices);
		}

		// Left height wall
		for ( x = 1; x <= MAP_HEIGHT/2; x++ )
		{
			sceGumLoadIdentity();
			{
				ScePspFVector3 pos = { 2*MAP_WIDTH, y*WALL_HEIGHT, x*4 };
				ScePspFVector3 rot = { 0, 90*toRads, 0 };
				sceGumTranslate(&pos);
				sceGumRotateXYZ(&rot);
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,2*3,0,wall_vertices);
		}

		// Right height wall
		for ( x = 0; x < MAP_HEIGHT/2; x++ )
		{
			sceGumLoadIdentity();
			{
				ScePspFVector3 pos = { 0, y*WALL_HEIGHT, x*4 };
				ScePspFVector3 rot = { 0, 270*toRads, 0 };
				sceGumTranslate(&pos);
				sceGumRotateXYZ(&rot);
			}

			sceGumDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,2*3,0,wall_vertices);
		}
	}


	return 1;
}

///////////// MAIN FUNCTION /////////////////
int main()
{ 
	// Initiate
	SetupCallbacks();
	pspDebugScreenInit();

	// Load textures and stuff
	initGraphics();


	// Camera Position
	camX = 6;
	camY = -1;
	camZ = 3;

	// Camera Rotation
	camXRot = 0;
	camYRot = 0;
	camZRot = 3;

	SceCtrlData pad;


	// FPS Counter
	u64 last_tick;
	sceRtcGetCurrentTick(&last_tick);
	u32 tick_res = sceRtcGetTickResolution();
	int frame_count = 0;

	Physics World;
	World.LEFT_X = 0;
	World.RIGHT_X = 20;
	World.UPPER_Y = 0;
	World.LOWER_Y = 40;

	World.FRICTION = 7.0f;
	World.GRAVITY = 0.0f;
	World.GRAVITY_ANGLE = 0.0f;
	World.LOSS_OF_ENERGY = 0.5f;

	World.SectionWidth = 30;
	World.SectionHeight = 50;
	World.SectionsX = 1;
	World.SectionsY = 1;

	ColCircle*	CameraObject = new ColCircle;
	CameraObject->x = camX;
	CameraObject->y = camZ;
	CameraObject->xsp = 0.0f;
	CameraObject->ysp = 0.0f;	
	CameraObject->mass = 10;
	CameraObject->size = 0.85f;
	World.AddCircle( CameraObject );	



	int	i;
	for (i = 0; i < MAX_DUCKS; i++)
	{
		Ducks[i] = NULL;
	}

	
	for (i = 0; i < 25; i++)
	{
	//	Ducks[i] = NULL;
		Ducks[i] = new Duck;
		Ducks[i]->Object = new ColCircle;
		Ducks[i]->Object->xsp = 0.0f;
		Ducks[i]->Object->ysp = 0.0f;
		Ducks[i]->Object->x = rand()%20;
		Ducks[i]->Object->y = rand()%40;
		Ducks[i]->Object->mass = 5.0f;
		Ducks[i]->Object->size = 0.75f;
		Ducks[i]->RotY = rand()%360;
		Ducks[i]->JumpDelay = rand()%15;
		Ducks[i]->RotSpeed = (rand()%1000/2 - 250);
		World.AddCircle( Ducks[i]->Object );
	}

	for ( i = 0; i < MAX_BOXES; i++ )
	{
		Boxes[i] = NULL;
	}

	for ( i = 0; i < 15; i++ )
	{
		Boxes[i] = new Box;
		Boxes[i]->Object = new ColCircle;
		Boxes[i]->Object->xsp = 0.0f;
		Boxes[i]->Object->ysp = 0.0f;
		Boxes[i]->Object->x = rand()%20;		
		Boxes[i]->Object->y = rand()%40;		
		Boxes[i]->Object->mass = 30.0f;		
		Boxes[i]->Object->size = 1.5f;		
		World.AddCircle( Boxes[i]->Object );
	}

	for ( i = 0; i < MAX_BRICKS; i++ )
	{
		Bricks[i] = NULL;
	}

	/*
	for ( i =0; i < 2; i++ )
	{
		Bricks[i] = new Brick;
		Bricks[i]->Object = new ColWall;
		Bricks[i]->Object->x1 = rand()%20;
		Bricks[i]->Object->x2 = rand()%20;
		Bricks[i]->Object->y1 = rand()%40;
		Bricks[i]->Object->y2 = rand()%40;
		Bricks[i]->Object->size = 0.1f;
	}
	*/
		

	World.Initialize();

/*	
	ScePspFVector3 lpos = { 5, 5, 5 }; 
	sceGuEnable(GU_LIGHTING); 
	sceGuEnable(GU_LIGHT0); 
	sceGuLight(0, 0, 0, &lpos); 
	sceGuLightColor(0, 2, 0xffffff); 
*/
	
	//ShowMessageDialog("Slasher pwns you");


	// Main loop //
	for(;;) {

		///////////////////
		////// Input //////
		///////////////////
		
		sceCtrlSetSamplingCycle(0);
 		sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
 		sceCtrlReadBufferPositive(&pad, 1);
 
		
		///// Controls /////

		// Reload
		if (pad.Buttons & PSP_CTRL_DOWN) {

		}
		// Shoot
		if (pad.Buttons & PSP_CTRL_CROSS) {

		}


		///// Movement /////
		bool moving = false;
		int analogX = pad.Lx - 128;
		int analogY = pad.Ly - 128;

		if (pad.Buttons & PSP_CTRL_TRIANGLE) {
			if ( CameraObject->y <= 0.0f )
			{	
			//	CameraObject->ysp = JUMP_SPEED;
			}
		}

		// Strafe Left
		if (pad.Buttons & PSP_CTRL_LTRIGGER) {
			if (!moving)
			{
				moving = true;
				bobAngle += curr_ms * BOB_SPEED;
			}
			CameraObject->xsp += cos(camYRot*toRads) * MOVE_SPEED * curr_ms;
			CameraObject->ysp += sin(camYRot*toRads) * MOVE_SPEED * curr_ms;
		}
		// Strafe Right
		if (pad.Buttons & PSP_CTRL_RTRIGGER) {
			if (!moving)
			{
				moving = true;
				bobAngle += curr_ms * BOB_SPEED;			
			}
			CameraObject->xsp -= cos(camYRot*toRads) * MOVE_SPEED * curr_ms;
			CameraObject->ysp -= sin(camYRot*toRads) * MOVE_SPEED * curr_ms;
		}

		if (!(pad.Buttons & PSP_CTRL_SQUARE)) {	// Not Holding Square, Analog is move
			// Move forwards & backwards
			if (fabs(analogY) > THRESHHOLD) {
				if (!moving)
				{
					moving = true;
					bobAngle += curr_ms * BOB_SPEED * ((float)fabs(analogY)/128);
				}
				CameraObject->xsp += cos((camYRot-90)*toRads) * MOVE_SPEED * curr_ms * ((float)analogY/128);
				CameraObject->ysp += sin((camYRot-90)*toRads) * MOVE_SPEED * curr_ms * ((float)analogY/128);
			}
			// Rotate Camera
			if (fabs(analogX) > THRESHHOLD) camYRot += (analogX) * curr_ms * SENSITIVITY;
		}
		else {					// Holding Square, Analog is look
			// Rotate Camera
			if (fabs(analogX) > THRESHHOLD) camYRot += analogX * curr_ms * SENSITIVITY;
			if (fabs(analogY) > THRESHHOLD) camXRot += analogY * curr_ms * SENSITIVITY;
			if (camXRot <= -90) camXRot = -90;
			if (camXRot >= 90) camXRot = 90;
		}

		if (bobAngle>=360) bobAngle -= 360;
		if (!moving && (bobAngle > (curr_ms*BOB_SPEED + 0.05f) ))
		{
			bobAngle += curr_ms * BOB_SPEED;
		}

		
		/////////////////////
		//// DUCK UPDATE ////
		/////////////////////
		int i;
		for ( i = 0; i < MAX_DUCKS; i++ )
		{
			if ( Ducks[i] != NULL )
			{
				Ducks[i]->RotY += Ducks[i]->RotSpeed * curr_ms;
				Ducks[i]->Object->xsp += sin(Ducks[i]->RotY*toRads) * curr_ms * DUCK_SPEED;
				Ducks[i]->Object->ysp += cos(Ducks[i]->RotY*toRads) * curr_ms * DUCK_SPEED;
				Ducks[i]->JumpDelay -= curr_ms;

				if (Ducks[i]->JumpDelay < 0)
				{
					Ducks[i]->JumpDelay = rand()%15;
				//	Ducks[i]->Object->ysp = 8.0f;
				}
			}
		}


		/////////////////
		//// PHYSICS ////
		/////////////////

		World.GlobalUpdate( curr_ms );

		
		///////////////////
		///// Render //////
		///////////////////

		// Start the scene
		sceGuStart(GU_DIRECT,list);

		// Clear the screen
		sceGuClearColor(RGB(177,225,254));
		sceGuClearDepth(0);
		sceGuClear(GU_COLOR_BUFFER_BIT|GU_DEPTH_BUFFER_BIT);


		// Drawing ///////////////////////////////////////////
	

		// The Camera
		camX = CameraObject->x;
		camZ = CameraObject->y;
		camY = 1 + sin(bobAngle*toRads)*0.05f;
				
		sceGumMatrixMode(GU_VIEW);
		sceGumLoadIdentity();
		{
			float lx, ly, lz;

			lx = sin(-camYRot*toRads);
			lz = cos(-camYRot*toRads);
			ly = tan(-camXRot*toRads);
			
			ScePspFVector3 pos = { camX, camY, camZ };
			ScePspFVector3 look = { camX + lx, camY + ly, camZ + lz };
			ScePspFVector3 tilt = { 0.0f, 1.0f, 0.0f };
			
			sceGumLookAt(&pos,&look,&tilt);
		}



		// Draw all models
		sceGumMatrixMode(GU_MODEL);
		
		// The Terrain
		drawTerrain();
		// The walls
		drawWalls();

#ifdef OUTLINES
		sceGuDisable(GU_DEPTH_TEST);
		// The ducks Outlines
		drawDucksOutline();
		// The Crates Outlines
//		drawBoxesOutline();
		sceGuEnable(GU_DEPTH_TEST);
#endif				

		// The ducks
		drawDucks();
		// The crates
		drawBoxes();


		// GIVE THE DUCKS GUNS!
		drawDucksGuns();
		


		// First Person Drawing
		drawFirstPerson();
		

		// End the scene
		sceGuFinish();
		sceGuSync(0, 0);


		// FPS
		//
		frame_count++;
 		u64 curr_tick;
		sceRtcGetCurrentTick(&curr_tick);
		float curr_fps = 1.0f / curr_ms;
		pspDebugScreenSetXY(0,0);
		pspDebugScreenPrintf("fps: %d.%03d ",(int)curr_fps,(int)((curr_fps-(int)curr_fps) * 1000.0f));
		double time_span = ((curr_tick-last_tick)) / (float)tick_res;
		curr_ms = time_span / frame_count;
		frame_count = 0;
		sceRtcGetCurrentTick(&last_tick);
		//
		// FPS


		// Flip
		frameBuffer = sceGuSwapBuffers();
	}


	// Done
	sceGuTerm();
	sceKernelSleepThread();
	
	return 0;
}

