#include <pspiofilemgr.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "config.h"

#define RGB(r, g, b) (0xFF000000 | ((b)<<16) | ((g)<<8) | (r))
#define isvalidvarchar(c) (isalnum(c) || c == '_' || c == '=')

int isspace(int c);
int isalnum(int c);

static int read_line(SceUID fd, char *line, int max)
{
	int i, read;
	char ch;

	i = 0;

	if (max == 0)
		return 1;

	do
	{
		read = sceIoRead(fd, &ch, 1);
		
		if (read && ch != '\n' && ch != '\r')
			line[i++] = ch;		

	} while (ch != '\n' && read == 1 && i < max);

	line[i] = 0;

	return !read;
}

static int get_tokens(char tokens[][128], int maxtokens, char *line)
{
	int iline = 0;
	int itoken = 0;
	int jtoken = 0;
	int intoken = 0;
	int instring = 0;
	char ch;

	while (itoken < maxtokens)
	{
		ch = line[iline++];

		if (ch == 0)
		{
			if (instring)
				return 0; // Error: not terminated string

			if (intoken)			
				tokens[itoken++][jtoken] = 0;

			break;
		}

		if (!instring && (ch == '#' || ch == ';'))
		{
			if (intoken)			
				tokens[itoken++][jtoken] = 0;

			break;
		}

		if (isspace(ch) || ch == '=')
		{
			if (intoken)
			{
				if (!instring)
				{
					intoken = 0;
					tokens[itoken++][jtoken] = 0;
					jtoken = 0;
				}

				else
				{
					tokens[itoken][jtoken++] = ch;
				}
			}
		}

		else if (ch == '"')
		{
			if (intoken)
			{
				if ((!instring && jtoken != 0) || 
					(instring && isvalidvarchar(line[iline])))
				{
					// Error: Mixing string token with something else 
					return 0; 
				}

				tokens[itoken][jtoken++] = ch;				
				instring = !instring;
			}
			
			else
			{
				intoken = 1;
				instring = 1;
				tokens[itoken][jtoken++] = ch;
			}
		}

		else if (isvalidvarchar(ch))
		{
			if (!intoken)
				intoken = 1;

			tokens[itoken][jtoken++] = ch;
		}

		else
		{
			if (instring)
				tokens[itoken][jtoken++] = ch;
		}
	}

	return itoken;
}

static int get_integer(char *str)
{
	return strtol(str, NULL, 0);
}

static int get_boolean(char *str)
{
	if (strcasecmp(str, "false") == 0)
		return 0;

	if (strcasecmp(str, "true") == 0)
		return 1;	

	if (strcasecmp(str, "off") == 0)
		return 0;

	if (strcasecmp(str, "on") == 0)
		return 1;

	return get_integer(str);
}

static char *get_string(char *out, int max, char *in)
{
	char *p;
	int len;
	
	memset(out, 0, max);

	if (in[0] != '"')
		return NULL;

	p = strchr(in+1, '"');

	if (!p)
		return NULL;

	if (p-(in+1) > max)
		len = max;
	else
		len = p-(in+1);

	strncpy(out, in+1, len);	

	return out;
}

void read_config(const char *file, CONFIGFILE *config)
{
	SceUID fd = sceIoOpen(file, PSP_O_RDONLY, 0777);

	/* Default: all values to zero */
	memset(config, 0, sizeof(CONFIGFILE));

	if (fd > 0)
	{
		int eof = 0, ntokens;
		char line[128];
		char tokens[2][128];
		
		while (!eof)
		{
			eof = read_line(fd, line, 127);
			ntokens = get_tokens(tokens, 2, line);	

			if (ntokens == 2)	// get_int( tokens[1] ); get_string(out, max, in); get_boolean( tokens[1] );
			{
				if (strcasecmp(tokens[0], "PlayerName") == 0)
				{
					get_string(config->PlayerName,32,tokens[1]);
				}
				else if (strcasecmp(tokens[0], "PlayerRed") == 0)
				{
					config->PlayerColor = config->PlayerColor | RGB( 0,0, get_integer(tokens[1]) );
				}
				else if (strcasecmp(tokens[0], "PlayerGreen") == 0)
				{
					config->PlayerColor = config->PlayerColor | RGB( 0, get_integer(tokens[1]), 0 );
				}
				else if (strcasecmp(tokens[0], "PlayerBlue") == 0)
				{
					config->PlayerColor = config->PlayerColor | RGB( get_integer(tokens[1]), 0, 0 );
				}
				else if (strcasecmp(tokens[0], "PlayerThreshhold") == 0)
				{
					config->PlayerThreshhold = get_integer( tokens[1] );
				}
				else if (strcasecmp(tokens[0], "PlayerSensitivity") == 0)
				{
					config->PlayerSensitivity = (float)(get_integer(tokens[1]))/10;
				}				
				else if (strcasecmp(tokens[0], "PlayerControls") == 0)
				{
					config->PlayerControls = get_integer(tokens[1]);
				}				
				else if (strcasecmp(tokens[0], "ServerName") == 0)
				{
					get_string(config->ServerName,32,tokens[1]);
				}
				else if (strcasecmp(tokens[0], "MaxPlayers") == 0)
				{
					config->ServerMaxPlayers = (short)get_integer(tokens[1]);
				}	
				else if (strcasecmp(tokens[0], "MasterServer") == 0)
				{
					get_string(config->MasterServer,32,tokens[1]);
				}
				else if (strcasecmp(tokens[0], "Port") == 0)
				{
					config->Port = get_integer(tokens[1]);
				}				
				else if (strcasecmp(tokens[0], "Connection") == 0)
				{
					config->ConnectionNum = get_integer(tokens[1]);
				}	
				else if (strcasecmp(tokens[0], "CelOutlines") == 0)
				{
					config->Outlines = (bool)get_boolean(tokens[1]);
				}
				else if (strcasecmp(tokens[0], "ConnectTime") == 0)
				{
					config->ConnectTime = get_integer(tokens[1])/50;
				}				
				else if (strcasecmp(tokens[0], "ConnectTries") == 0)
				{
					config->ConnectTries = get_integer(tokens[1]);
				}
				else if (strcasecmp(tokens[0], "BufferSize") == 0)
				{
					config->BufferSize = get_integer(tokens[1]);
				}
				else if (strcasecmp(tokens[0], "NumTempSockets") == 0)
				{
					config->NumTempSockets = get_integer(tokens[1]);
				}			
				else if (strcasecmp(tokens[0], "Timeout") == 0)
				{
					config->Timeout = get_integer(tokens[1]);
				}	
				else if (strcasecmp(tokens[0], "InitialConnectTimeout") == 0)
				{
					config->InitialConnectTimeout = get_integer(tokens[1])/50;
				}
				else if (strcasecmp(tokens[0], "Overclock") == 0)
				{
					config->Overclock = (bool)get_boolean(tokens[1]);
				}			
 				else if (strcasecmp(tokens[0], "Vsync") == 0)
				{
					config->Vsync = (bool)get_boolean(tokens[1]);
				}				
				else if (strcasecmp(tokens[0], "ReadLocalConfig") == 0)
				{
					config->Read = (bool)get_boolean(tokens[1]);
				}
				else if (strcasecmp(tokens[0], "DebugMode") == 0)
				{
					config->DebugMode = (bool)get_boolean(tokens[1]);
				}
				else if (strcasecmp(tokens[0], "Game" ) == 0 )
				{
					config->Game = get_integer(tokens[1]);
				}
			}
		}

		sceIoClose(fd);
	}
//	config->DebugMode = true;
}
