///////////////////
////// Input //////
///////////////////

SceCtrlData pad, old;


int	initInput()
{
	sceCtrlSetSamplingCycle(0);
	sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
	sceCtrlReadBufferPositive(&pad, 1);

	return 1;
}


int	Game_Input()
{

	old = pad;
	sceCtrlReadBufferPositive(&pad, 1);

	bool moving = false;
	int analogX = pad.Lx - 128;
	int analogY = pad.Ly - 128;

	// Constant Input here
	// (Start) Exit
	if ( pad.Buttons & PSP_CTRL_START ) return 0;
	
	// (Select) Score
		


	if ( Player1.physical->alive )
	{
		switch (Config.PlayerControls)
		{
		case 1:

			///// Control Scheme 1 /////

			// Reload
			if (pad.Buttons & PSP_CTRL_DOWN) {

			}
			// Shoot
			if (pad.Buttons & PSP_CTRL_CROSS) {

			}

			///// Movement /////

			if (pad.Buttons & PSP_CTRL_TRIANGLE) {
				if ( Player1.physical->Object->y <= 0.0f )
				{	
				//	CameraObject->ysp = JUMP_SPEED;
				}
			}

			// Strafe Left
			if (pad.Buttons & PSP_CTRL_LTRIGGER) {
				if (!moving)
				{
					moving = true;
					Player1.bobAngle += dt * BOB_SPEED;
				}
				Player1.physical->Object->xsp += cos(Player1.physical->YRot*toRads) * MOVE_SPEED * dt;
				Player1.physical->Object->ysp += sin(Player1.physical->YRot*toRads) * MOVE_SPEED * dt;
			}
			// Strafe Right
			if (pad.Buttons & PSP_CTRL_RTRIGGER) {
				if (!moving)
				{
					moving = true;
					Player1.bobAngle += dt * BOB_SPEED;			
				}
				Player1.physical->Object->xsp -= cos(Player1.physical->YRot*toRads) * MOVE_SPEED * dt;
				Player1.physical->Object->ysp -= sin(Player1.physical->YRot*toRads) * MOVE_SPEED * dt;
			}

			if (!(pad.Buttons & PSP_CTRL_SQUARE)) {	// Not Holding Square, Analog is move
				// Move forwards & backwards
				if (fabs(analogY) > Config.PlayerThreshhold) {
					if (!moving)
					{
						moving = true;
						Player1.bobAngle += dt * BOB_SPEED * ((float)fabs(analogY)/128);
					}
					Player1.physical->Object->xsp += cos((Player1.physical->YRot-90)*toRads) * MOVE_SPEED * dt * ((float)analogY/128);
					Player1.physical->Object->ysp += sin((Player1.physical->YRot-90)*toRads) * MOVE_SPEED * dt * ((float)analogY/128);
				}
				// Rotate Camera
				if (fabs(analogX) > Config.PlayerThreshhold) Player1.physical->YRot += (analogX) * dt * Config.PlayerSensitivity;
			}
			else {					// Holding Square, Analog is look
				// Rotate Camera
				if (fabs(analogX) > Config.PlayerThreshhold) Player1.physical->YRot += analogX * dt * Config.PlayerSensitivity;
				if (fabs(analogY) > Config.PlayerThreshhold) Player1.physical->XRot += analogY * dt * Config.PlayerSensitivity;
				if (Player1.physical->XRot <= -90) Player1.physical->XRot = -90;
				if (Player1.physical->XRot >= 90) Player1.physical->XRot = 90;
			}

			break;

		default:
			break;
		}
	}


	if (Player1.bobAngle>=360) Player1.bobAngle -= 360;
	if (!moving && (Player1.bobAngle > (dt*BOB_SPEED + 0.05f) ))
	{
		Player1.bobAngle += dt * BOB_SPEED;
	}	

	return 1;
}
