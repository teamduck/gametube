
#define		MAX_GAMES	16
#define		MAX_PLAYERS	8

#define		RESPAWN_TIME			5.0f	// Seconds
#define		MASTER_SERVER_UPDATE_TIME	30.0f	// Less than a minute, keeps WLAN init()
#define		PHYSICAL_UPDATE_TIME		1.0f	// 10 fps - Smooth enough with out slowing the Client
#define		BOX_UPDATE_TIME			40.0f	// Every 40 seconds / 8 Players = Every 5 seconds sync (kinda)


// Struct that game info is sent from the server in
struct	ShortInfo
{
	short	id;
	char 	name[32];
	char 	maxPlayers, curPlayers;
};


struct	Player
{
	char	name[32];
	int	color;
	short	kills, deaths;
};

struct Physical
{
	int		alive;
	ColCircle*	Object;
	int		ObjectIndex;
	float		XRot;
	float		YRot;
};


// Info for all the Nodes/Clients/Players
struct	Node
{
	int			connected;
	char		ip[16];
	Socket*		socket;
	Player*		player;
	Physical* 	physical;
};

// Extra Info for Player1
struct P1
{
	// Special Storage for our IP
	char	IP[16];
	// Storage for the ID of the active game
	short	gameId;
	
	// Pointers to its data along with everyone elses
	Node*		node;
	Player*		player;
	Physical*	physical;

	// Extra data
	float		respawnTime;
	float		shootDelay;
	float		bobAngle;

	// Network Timing
	float		masterServerUpdate;
	float		physicalUpdate;
	float		boxUpdate;


} Player1;

// Boxes
#define		MAX_BOXES	25	// If it was 30, the buffer would've had to be bigger
#define		BOX_SIZE	1.5f

struct Box
{
	ColCircle*	Object;
};

Box*	Boxes[MAX_BOXES];


// All of the nodes
Node	nodes[MAX_PLAYERS];


// TODO: Finish networking framework

#define		MAX_TEMP_SOCKS		10


// Buffers
char* outbuf;
char* inbuf;

// Sockets
Socket* masterServer;
Socket*	listenSock;
Socket* tempSocks[MAX_TEMP_SOCKS];
int	tempTimeouts[MAX_TEMP_SOCKS];


Socket*	Connect( const char* Server, int Port, int Tries )
{
	Socket* sock;

	int j;
	for ( j = 0; j < Tries; j++ )
	{
		// Initial Connect
		sock = Socket_connect(Server,Port);
		if ( sock == NULL ) return NULL;
	
		// Try for 1 second
		int i;
		for ( i = 0; i < Config.ConnectTime; i++ )
		{
			if (Socket_isConnected(sock)) break;
			sceKernelDelayThread(50*1000);
		}

		sceKernelDelayThread(50*1000);	

		// If it worked, return the socket
		if (Socket_isConnected(sock))
		{
			return sock;
		} 

		// Other wise, delete the socket & try again
		Socket_close(sock);
	}
	
	// Failed
	return NULL;
}


int	initWlan()
{
	// Clear EVERYTHING
	masterServer = NULL;
	listenSock = NULL;

	int i;
	for ( i = 0; i < MAX_TEMP_SOCKS; i++ )
	{
		tempSocks[i] = NULL;
		tempTimeouts[i] = 0;
	}
		
	
	// Clear the nodes	
	memset( nodes, 0, sizeof(Node) * MAX_PLAYERS );
	memset( &Player1, 0, sizeof(P1) );
	
	// Allocate Buffers
	outbuf = (char*)malloc(sizeof(char)*Config.BufferSize);
	inbuf = (char*)malloc(sizeof(char)*Config.BufferSize);

	// Clear the buffers
	memset(outbuf, 0, sizeof(char)*Config.BufferSize);
	memset(inbuf, 0, sizeof(char)*Config.BufferSize);	
	
	// Set up Wlan
	if ( !Wlan_init() ) return 0;

	// Connect to Wlan
	if (Wlan_useConnectionConfig(Config.ConnectionNum - 1)==0) return 0;


	return 1;
}


int	shutdownWlan()
{
	Wlan_term();
	
	// Free Buffers
	free(outbuf);
	free(inbuf);

	return 1;
}

ShortInfo*	getGameList( int* num )
{
	// Ask for the Game List
	// (Make sure the connection didnt timeout)
	if ( masterServer == NULL || !Socket_isConnected( masterServer ) )
	{
		masterServer = Connect( Config.MasterServer, Config.Port, Config.ConnectTries );
		if ( masterServer == NULL )
		{
			*num = 1;
			return NULL;
		}

		// Delay to reduce chance of packet being missed
		sceKernelDelayThread(500*1000);		
	}

	// Send "REFRESH" Message
	sprintf( outbuf, "REFRESH" );	
	Socket_send( masterServer, (void*)outbuf, Config.BufferSize );	
		
	// Wait for list
	int i;
	for(i = 0; i < Config.InitialConnectTimeout; i++)
	{
		Socket_recv( masterServer, (void*)inbuf, Config.BufferSize );
		if (inbuf[0] != '\0')
		{
			if (strncasecmp(inbuf,"LIST", 4)==0)
			{
				printf("Got List \n");
				
				// Decode the list
				// Find # of games
				short n;
				memcpy( &n, inbuf+16, sizeof(short) );

				// Get the number of games
				*num = n;

				// If 0 then done
				if ( num == 0 ) return NULL;

				printf("Attempting Data Copy \n");

				ShortInfo* data = (ShortInfo*)malloc(sizeof(ShortInfo)*n);

				// Copy it all
				memcpy( data, inbuf+18, sizeof(ShortInfo)*n);

				printf("Copy Success \n");				
				
				return data;
			}
		}
	
		sceKernelDelayThread(50*1000);

		// If the Connection is lost
		if ( !Socket_isConnected(masterServer) )
		{	// Retry it 3 times
			masterServer = Connect( Config.MasterServer, Config.Port, Config.ConnectTries );
			// If that fails, quit
			if (masterServer == NULL)
			{
				*num = 1;
				return NULL;
			}
		}		
	}	

	*num = 1;
	return NULL;
}

int	getIp()
{
	if ( masterServer == NULL || !Socket_isConnected(masterServer) )
	{
		masterServer = Connect( Config.MasterServer, Config.Port, Config.ConnectTries );
		if ( masterServer == NULL )
		{
			return 0;
		}
		
		// Delay to reduce chance of packet being missed
		sceKernelDelayThread(500*1000);		
	}

	printf("Connected to server \n");

	// Ask whats my ip
	
	
	sprintf( outbuf, "MYIP" );
	Socket_send( masterServer, (void*)outbuf, Config.BufferSize );


	// Wait for IP, then disconnect
	int i;
	for(i = 0; i < Config.InitialConnectTimeout; i++)
	{
	
		Socket_recv( masterServer, (void*)inbuf, Config.BufferSize );
		if (inbuf[0] != '\0')
		{
			printf( inbuf );
			if (strncasecmp(inbuf,"YOURIP", 6)==0)
			{
				char	ip[16];
				memcpy(ip,inbuf+16,16);
				if ( strlen(ip) > 6 )
				{
					memcpy( Player1.IP, ip, 16 );
				}
				break;
			}
		}
		
		sceKernelDelayThread(50*1000);

		// If the Connection is lost
		if ( !Socket_isConnected(masterServer) )
		{	// Retry it 3 times
			masterServer = Connect( Config.MasterServer, Config.Port, Config.ConnectTries );
			// If that fails, quit
			if (masterServer == NULL)
				return 0;
		}
	}	

	if ( strlen(Player1.IP) < 6 ) 
		return 0;

	if ( i < Config.InitialConnectTimeout )
		return 1;


	return 0;
}


int	fakeIp()
{
	if ( masterServer == NULL || !Socket_isConnected(masterServer) )
	{
		masterServer = Connect( Config.MasterServer, Config.Port, Config.ConnectTries );
		if ( masterServer == NULL )
		{
			return 0;
		}
		
		// Delay to reduce chance of packet being missed
		sceKernelDelayThread(500*1000);		
	}

	printf("Connected to server \n");

	// Ask whats my ip
	
	
	sprintf( outbuf, "MYIP" );
	Socket_send( masterServer, (void*)outbuf, Config.BufferSize );


	// Wait for IP, then disconnect
	int i;
	for(i = 0; i < Config.InitialConnectTimeout; i++)
	{
	
		Socket_recv( masterServer, (void*)inbuf, Config.BufferSize );
		if (inbuf[0] != '\0')
		{
			printf( inbuf );
			if (strncasecmp(inbuf,"YOURIP", 6)==0)
			{
				break;
			}
		}
		
		sceKernelDelayThread(50*1000);

		// If the Connection is lost
		if ( !Socket_isConnected(masterServer) )
		{	// Retry it 3 times
			masterServer = Connect( Config.MasterServer, Config.Port, Config.ConnectTries );
			// If that fails, quit
			if (masterServer == NULL)
				return 0;
		}
	}	

	if ( i < Config.InitialConnectTimeout )
		return 1;

	return 0;
}



int	newGame()
{
	printf("Requesting new game \n");
	
	// Close the socket
	Socket_close( masterServer );
	masterServer = NULL;

	
	// Try to get the IP twice first ( for kicks )
	if (!fakeIp())
		fakeIp();
	
	// If the Connection is lost
	if ( masterServer == NULL || !Socket_isConnected(masterServer) )
	{	// Retry it 3 times
		masterServer = Connect( Config.MasterServer, Config.Port, Config.ConnectTries );
		// If that fails, quit
		if (masterServer == NULL)
			return 0;
		
	}

	// Delay to reduce chance of packet being missed
	sceKernelDelayThread(300*1000);		
	
	// This is important since it can only be sent once
	sprintf( outbuf, "NEWGAME" );
	sprintf( outbuf + 16, Config.ServerName );	
	memcpy( outbuf + 48, ((char*)&Config.ServerMaxPlayers), 1 );

	int bytes = Socket_send( masterServer, (void*)outbuf, Config.BufferSize );
	if ( bytes < Config.BufferSize )	// If the message didnt get sent, try again
	{
		printf("Message wasn't sent whole \n");
		// If the Connection is lost
		if ( !Socket_isConnected(masterServer) )
		{	// Retry it 3 times
			masterServer = Connect( Config.MasterServer, Config.Port, Config.ConnectTries );
			// If that fails, quit
			if (masterServer == NULL)
				return 0;
		}
		Socket_send( masterServer, (void*)outbuf, 16 );		
	}
	
	printf("Waiting for Game Id message \n");	
		
	// Wait for Game ID #
	int i;
	for(i = 0; i < Config.InitialConnectTimeout; i++)
	{
		Socket_recv( masterServer, (void*)inbuf, Config.BufferSize );
		
		if (inbuf[0] != '\0')
		{
			if (strncasecmp(inbuf,"SERVID", 6)==0)
			{
				memcpy(&Player1.gameId,inbuf+16,2);
				printf("Game ID is %i \n", (int)(Player1.gameId));
				break;
			}
		}

		sceKernelDelayThread(50*1000);		
		
		// If the Connection is lost
		if ( !Socket_isConnected(masterServer) )
		{	// Retry it 3 times
			masterServer = Connect( Config.MasterServer, Config.Port, Config.ConnectTries );
			// If that fails, quit
			if (masterServer == NULL)
				return 0;
		}		
	}

	if ( i == Config.InitialConnectTimeout ) return 0;

	
	// Setup the game
	
	// Clear the nodes	
	memset( nodes, 0, sizeof(Node) * MAX_PLAYERS );
	memset( &Player1, 0, sizeof(P1) );

	// Make P1 Node
	nodes[0].connected = 2;
	nodes[0].socket = NULL;
	sprintf(nodes[0].ip, Player1.IP );
	Player1.node = &nodes[0];

	// Make P1 Player
	nodes[0].player = (Player*)malloc(sizeof(Player));
	Player1.player = nodes[0].player;
	sprintf( Player1.player->name, Config.PlayerName );
	Player1.player->color = Config.PlayerColor;
	Player1.player->kills = 0;
	Player1.player->deaths = 0;

	// Make P1 Physical
	nodes[0].physical = (Physical*)malloc(sizeof(Physical));
	Player1.physical = nodes[0].physical;
	Player1.physical->alive = false;
	Player1.physical->Object = NULL;
	Player1.physical->ObjectIndex = 0;
	Player1.physical->XRot = 0;
	Player1.physical->YRot = 0;

	// Player1 P1
	Player1.respawnTime = RESPAWN_TIME;
	Player1.shootDelay = 0;
	Player1.bobAngle = 0;

	Player1.masterServerUpdate = MASTER_SERVER_UPDATE_TIME;
	Player1.physicalUpdate = PHYSICAL_UPDATE_TIME;
	Player1.boxUpdate = BOX_UPDATE_TIME;

	// Set up boxes
	for ( i = 0; i < MAX_BOXES; i++ )
		Boxes[i] = NULL;	
	
	for ( i = 0; i < 15; i++ )
	{
		Boxes[i] = new Box;
		Boxes[i]->Object = new ColCircle;
		Boxes[i]->Object->kind = 0;
		Boxes[i]->Object->xsp = 0.0f;
		Boxes[i]->Object->ysp = 0.0f;
		Boxes[i]->Object->x = rand()%MAP_WIDTH;		
		Boxes[i]->Object->y = rand()%MAP_HEIGHT;		
		Boxes[i]->Object->size = BOX_SIZE;		
		World->AddCircle( Boxes[i]->Object );
	}

	// Set up the ListenSock
	listenSock = Socket_createServerSocket( Config.Port );
	if ( listenSock == NULL ) return 0;	

	// Clear the tempSocks

	for ( i = 0; i < MAX_TEMP_SOCKS; i++ )
	{
		tempSocks[i] = NULL;
		tempTimeouts[i] = 0;
	}
	
	// Enter Main Loop
	printf("Create Success, Entering Game \n");

	// Enter the game
	game();
	
	return 1;
}

int	joinGame( short id )
{
	printf("Joining Game #%i \n",(int)id);
	printf("Requesting Member List \n");

	Socket_close(masterServer);
	masterServer = NULL;
	
	// If the Connection is lost
	if ( masterServer == NULL || !Socket_isConnected(masterServer) )
	{	// Retry it 3 times
		masterServer = Connect( Config.MasterServer, Config.Port, Config.ConnectTries );
		// If that fails, quit
		if (masterServer == NULL)
			return 0;
		// Delay to reduce chance of packet being missed
		sceKernelDelayThread(400*1000);		
	}
	

	// Request A Member List for the Game
	sprintf(outbuf, "IPTABLE");
	memcpy( (outbuf+16), &id, 2 );	// Add the game ID#	
	Socket_send( masterServer, (void*)outbuf, Config.BufferSize );	

	// Table for retrieved IP's
	short numips;
	char ips[MAX_PLAYERS][16];
	
	// Loop for response
	int i;
	for(i = 0; i < Config.InitialConnectTimeout; i++)
	{
		Socket_recv( masterServer, (void*)inbuf, Config.BufferSize );
		if (inbuf[0] != '\0')
		{
			if (strncasecmp(inbuf,"TABLE", 5)==0)
			{
				memcpy(&numips,inbuf+16,2);
				char* mem = inbuf + 16 + 2;
				printf("Found %i possible nodes \n", (int)numips);
				int i;
				
				// Clear them
				for ( i = 0; i < MAX_PLAYERS; i++ )
					ips[i][0] = '\0';
				
				// Fill them
				for ( i = 0; i < numips; i++ )
				{
					memcpy(ips[i], mem, 16);
					mem += 16;
				}
				
				break;
			}
		}	

		sceKernelDelayThread(50*1000);	
		
		// If the Connection is lost
		if ( !Socket_isConnected(masterServer) )
		{	// Retry it 3 times
			masterServer = Connect( Config.MasterServer, Config.Port, Config.ConnectTries );
			// If that fails, quit
			if (masterServer == NULL)
				return 0;

			// Resend our request (since the server disconnected us probably)
			Socket_send( masterServer, (void*)outbuf, 18 );				
		}		
	}

	if ( i == Config.InitialConnectTimeout ) return 0;

	printf("Joining Members \n");	

	// Create the temporary sockets
	Socket*	socks[MAX_PLAYERS];

	for ( i = 0; i < MAX_PLAYERS; i++ )
		socks[i] = NULL;


	// Clear the nodes	
	memset( nodes, 0, sizeof(Node) * MAX_PLAYERS );
	memset( &Player1, 0, sizeof(P1) );

	
	// Send each an "IJOIN"
	// If you get a response, then turn it into a node
	// When REQALL data arrives, look for any new nodes
	// And connect to them
	
	int reqall = -1;
	int numWork = 0;

	// Connect to each potential
	for ( i = 0; i < MAX_PLAYERS; i++ )
	{
		if ( strlen(ips[i]) > 6 )
		{
			// Give it 3 tries
			printf( "Trying: %s \n", ips[i] );
			socks[i] = Connect(ips[i], Config.Port, Config.ConnectTries);
			
			// Connection Established
			if ( socks[i] != NULL )
			{
				// Count it
				numWork++;
				
				// Add it as a real node
				int j;
				for ( j = 0; j < MAX_PLAYERS; j++ )
				{
					if ( nodes[j].connected == false )
					{
						
						nodes[j].connected = 2;
						sprintf(nodes[j].ip, ips[i]);
						nodes[j].socket = socks[i];

						break;
					}
				}

				// This is the node we ask for all the info
				// We want it to be the last node we talk to
				// So that the connection is less likely to
				// have timed out.
				reqall = j;
				
				// Give it an IJOIN signal + Your Name
				sprintf( outbuf, "IJOIN" );
				sprintf( (outbuf+16), Player1.IP );
				Socket_send(socks[i], (void*)outbuf, Config.BufferSize );

			}
		}
	}

	// No Successful Connections
	if ( numWork == 0 )
	{
		printf("No Successful Connections to Nodes \n");
		return 0;
	}

	// Clear the boxes
	int k;
	for ( k = 0; k < MAX_BOXES; k++ )
		Boxes[k] = NULL;

	// If its not connected, re-connect with it
	if ( !Socket_isConnected(nodes[reqall].socket ) )
	{
		nodes[reqall].socket = Connect( nodes[reqall].ip, Config.Port, Config.ConnectTries );
		// Failure, could not connect with Reqall Node
		if ( nodes[reqall].socket == NULL )
		{
			printf("Could not connect to Reqall Node \n");
			return 0;
		}
	}
	
	// Requesting Game Info from our favorite Node
	printf("Requesting Game Info with REQALL \n");	
	sprintf( outbuf, "REQALL1" );
	Socket_send( nodes[reqall].socket, outbuf, Config.BufferSize );
			
	bool 	receive = false;
	int	getAllPhase = 0;
	
	// Loop for response
	for(i = 0; i < Config.InitialConnectTimeout*3; i++)
	{
		// Send whats in the Outbuffer ("REQALL1" or "REQALL2" )
		Socket_send( nodes[reqall].socket, outbuf, Config.BufferSize );

		Socket_recv( nodes[reqall].socket, (void*)inbuf, Config.BufferSize );
		if (inbuf[0] != '\0')
		{
			receive = true;
			printf("Message from REQALL \n");

			// Get all nodes
			if (strncasecmp(inbuf,"GALL1", 5)==0 && getAllPhase == 0)	// Gall1, Nodes
			{
				receive = true;	
				getAllPhase = 1;		
				
				short num;
				memcpy(&num,inbuf+16,2);
				char* mem = (inbuf+16+2);

				char	tempip[16];

				int z;
				for ( z = 0; z < num; z++ )
				{
					printf("Checking node %i of %i \n", (z+1), (int)num);

					sprintf( tempip, mem );
					
					// Look for IP
					int u;
					for ( u = 0; u < MAX_PLAYERS; u++ )
					{
						if ( strcmp(nodes[u].ip,tempip) == 0 )
							break;
					}
					if ( u == MAX_PLAYERS )	// if we dont have it, add it & connect to it
					{
						// If we don't have it
						// Add it and connect to it
						for ( u = 0; u < MAX_PLAYERS; u++ )
							if ( nodes[u].connected == false ) break;
						
						sprintf(nodes[u].ip, tempip);

						if ( strcmp( nodes[u].ip, Player1.IP ) )
						{
							// If it isn't us, then try to connect to it
							nodes[u].socket = Connect( nodes[u].ip, Config.Port, Config.ConnectTries );
							
							if ( nodes[u].socket )	// If it connected, tell us
							{			
								printf( " Node %s has connected \n", nodes[u].ip );
								nodes[u].connected = 2;
							} else {				// Otherwise, ignore it for now (Serious Error, Later)
								printf( " Couldn't Connect to Node \"%s\" \n", nodes[u].ip );
								nodes[u].connected = 0;
							}
						} else {
							// If it is us, than just say its connected
							nodes[u].connected = 1;
						}
					}

					// Now that we definately have it
					// Allocate the structs for it
					// Add then add all the info for it
					if ( nodes[u].connected )	// If we have it
					{
						// Make a new Player for it
						nodes[u].player = (Player*)malloc(sizeof(Player));
						
						// Get Player-Name
						sprintf( nodes[u].player->name, "-----" );

						// Get the Player-Color
						nodes[u].player->color = RGB(255,255,0);

						// Get the Kills
						nodes[u].player->kills = 0;

						// Get the Deaths
						nodes[u].player->deaths = 0;

						// Make a Physical for it
						nodes[u].physical = (Physical*)malloc(sizeof(Physical));

						nodes[u].physical->alive = false;
						nodes[u].physical->Object = NULL;
						nodes[u].physical->ObjectIndex = 0;
						nodes[u].physical->XRot = 0;
						nodes[u].physical->YRot = 0;
					}

					mem += (16);
				}

				// Send REQALL2 Message
				sprintf( outbuf, "REQALL2" );
				Socket_send( nodes[reqall].socket, outbuf, Config.BufferSize );	

				// Reset Timeout
				i = 0;				
				
			// Get all the crates!
			} else if (strncasecmp(inbuf,"GALL2", 5)==0) {
				short num;			// Number of crates
				memcpy(&num,inbuf+16,2);	
				char* memn = (inbuf+16+2);	// mem pointer (current position)
				
				int z, u;
				for ( z = 0; z < num; z++ )
				{
					for ( u = 0; u < MAX_BOXES; u++ )
					{
						if ( Boxes[u] == NULL ) break;
					}
					
					Boxes[u] = new Box;
					Boxes[u]->Object = new ColCircle;
					Boxes[u]->Object->xsp = 0;
					Boxes[u]->Object->ysp = 0;
					Boxes[u]->Object->kind = 0;
					Boxes[u]->Object->size = BOX_SIZE;

					memcpy( &Boxes[u]->Object->x, memn, sizeof(float) );
					memn += sizeof(float);
					memcpy( &Boxes[u]->Object->y, memn, sizeof(float) );
					memn += sizeof(float);	
				}

				// Done with Reqall
				break;
			}
		}

		// Short Delay
		sceKernelDelayThread(50*1000);

		// If its not connected, re-connect with it
		if ( !Socket_isConnected(nodes[reqall].socket ) )
		{
			nodes[reqall].socket = Connect( nodes[reqall].ip, Config.Port, Config.ConnectTries );
			// Failure, could not connect with Reqall Node
			if ( nodes[reqall].socket == NULL )
			{
				printf("Disconnected from Reqall Node \n");
				return 0;
			}
		}			
	}

	if ( i >= Config.InitialConnectTimeout*3 ) 
	{
		printf("Reqall Timeout \n");	
		return 0;
	}

	// Few final inits() before entering game
	// Set up Player1 & Net Timing & Respawn Timing
	for ( i = 0; i < MAX_PLAYERS; i++ )
	{
		if ( nodes[i].connected && strcmp( nodes[i].ip, Player1.IP ) == 0 )
		{
			break;
		}
	}

	if ( i == MAX_PLAYERS )
	{
		printf( " Error, could not find self \"%s\" \n", Player1.IP );
		return 0;
	}
	
	Player1.node = &nodes[i];
	Player1.player = nodes[i].player;
	Player1.physical = nodes[i].physical;

	Player1.physical->alive = false;
			
	Player1.respawnTime = RESPAWN_TIME;
	Player1.shootDelay = 0;
	Player1.bobAngle = 0;

	Player1.masterServerUpdate = MASTER_SERVER_UPDATE_TIME;
	Player1.physicalUpdate = PHYSICAL_UPDATE_TIME;
	Player1.boxUpdate = BOX_UPDATE_TIME;	
	
	// Add gameId
	Player1.gameId = id;

	// Set up the ListenSock
	listenSock = Socket_createServerSocket( Config.Port );	
	if ( listenSock == NULL ) return 0;

	// Clear the tempSocks
	for ( i = 0; i < MAX_TEMP_SOCKS; i++ )
	{
		tempSocks[i] = NULL;
		tempTimeouts[i] = 0;
	}

	Socket_close( masterServer );
	masterServer = Connect( Config.MasterServer, Config.Port, 1 );

	// Tell server about it
	sprintf( outbuf, "INGAME" );
	memcpy( outbuf+16, &Player1.gameId, 2 );
	char* pt = outbuf + 20;
	short numPlayers;
	int w;
	for ( w = 0; w < MAX_PLAYERS; w++ )
	{
		if ( nodes[w].connected )
		{
			memcpy( pt, nodes[w].ip, 16 );
			pt += 16;
			numPlayers++;
		}
	}
	memcpy( outbuf+18, &numPlayers, 2 );
	
	Socket_send( masterServer, outbuf, Config.BufferSize );	
	
	// And Then Enter Main Loop
	printf("Join Success, Entering Game! \n");
	game();

	return 1;
}

// Sends a message in the Out Buffer to all active nodes
int	SendMessage()
{
	int i;
	for ( i = 0; i < MAX_PLAYERS; i++ )
	{
		// If it's connected and not the player, then send it
		if ( nodes[i].connected > 1 && strcmp( Player1.IP, nodes[i].ip ) && nodes[i].socket != NULL )
		{
			Socket_send( nodes[i].socket, (void*)outbuf, Config.BufferSize );
		}
	}

	return 1;
}

int	Game_Network()
{

	if ( Config.DebugMode ) printf("New Connections \n");
	
	int q;
	// Incoming Connections		/////////////////////////////////////////////
	for ( q = 0; q < Config.NumTempSockets; q++ )
	{
		if ( tempSocks[q] == NULL )
		{
			tempSocks[q] = Socket_accept(listenSock);
			if ( tempSocks[q] != NULL )
			{
				if ( Config.DebugMode ) printf("New Connection \n");
			}
		} else {
			if ( Socket_isConnected( tempSocks[q] ) )
			{
				Socket_recv( tempSocks[q], inbuf, Config.BufferSize );
				if (inbuf[0] != '\0')
				{
					if (strncasecmp(inbuf,"IJOIN", 5)==0)
					{
						// They're Joining, add them as a node
						int i;
						for ( i = 0; i < MAX_PLAYERS; i++ )
						{
							if (nodes[i].connected == false) break;
						}

						if ( i == MAX_PLAYERS )
						{	// Tell them it's full, and disconnect them
							sprintf( outbuf, "GAMEFULL" );
							Socket_send( tempSocks[q], (void*)outbuf, Config.BufferSize );
							Socket_close( tempSocks[q] );
							tempSocks[q] = NULL;
							tempTimeouts[q] = 0;
						} else {
							
							nodes[i].connected = 1;
							sprintf(nodes[i].ip,(inbuf+16));
							if ( Config.DebugMode ) printf("New Node IP: %s \n", nodes[i].ip);
							nodes[i].socket = tempSocks[q];
							tempSocks[q] = NULL;
							tempTimeouts[q] = 0;

							// Make a Player & Physical
							nodes[i].player = (Player*)malloc(sizeof(Player));
							sprintf(nodes[i].player->name, "-----");
							if ( Config.DebugMode ) printf("New Node Name: %s \n",nodes[i].player->name);
							nodes[i].player->color = RGB(255,255,0);
							nodes[i].player->kills = 0;
							nodes[i].player->deaths = 0;

							// Make physical
							nodes[i].physical = (Physical*)malloc(sizeof(Physical));
							nodes[i].physical->alive = false;
							nodes[i].physical->Object = NULL;
							nodes[i].physical->ObjectIndex = 0;
							nodes[i].physical->XRot = 0;
							nodes[i].physical->YRot = 0;
							tempSocks[q] = NULL;
							tempTimeouts[q] = 0;
						}
						
					} else if ( strncasecmp(inbuf, "RECONNECT", 9)==0) {
						char tempIp[16];
						sprintf( tempIp, Socket_toString(tempSocks[q]));
						
						// Check to see if we already have them as a node
						// By searching for tempIp in the nodes
						int j;
						for ( j = 0; j < MAX_PLAYERS; j++ )
						{
							if ( nodes[j].connected == true )
							{
								if ( strcmp(nodes[j].ip,tempIp) == 0 )
									break;
							}
						}
						
						// If we do, update the socket with the working one
						if ( j < MAX_PLAYERS )
						{
							nodes[j].socket = tempSocks[q];
						} else {
							// If we don't, make a new node
							for ( j = 0; j < MAX_PLAYERS; j++ )
							{
								if ( nodes[j].connected == false ) break;
							}

							if ( j == MAX_PLAYERS )
							{	// Tell them it's full, and disconnect them
								sprintf( outbuf, "GAMEFULL" );
								Socket_send(tempSocks[q], (void*)outbuf, Config.BufferSize );
								Socket_close( tempSocks[q] );
								tempSocks[q] = NULL;
								tempTimeouts[q] = 0;
							} else {
								nodes[j].connected = true;
								sprintf(nodes[j].ip,tempIp);
								if ( Config.DebugMode ) printf("New Node IP: %s \n", nodes[j].ip);
								nodes[j].socket = tempSocks[q];
								tempSocks[j] = NULL;
								tempTimeouts[j] = 0;

								// Make a Player & Physical
								nodes[j].player = (Player*)malloc(sizeof(Player));
								sprintf(nodes[j].player->name, (inbuf+16));
								if ( Config.DebugMode ) printf("New Node Name: %s \n",nodes[j].player->name);
								memcpy( &nodes[j].player->color, (inbuf+48), 4);
								nodes[j].player->kills = 0;
								nodes[j].player->deaths = 0;

								// Make physical
								nodes[j].physical = (Physical*)malloc(sizeof(Physical));
								nodes[j].physical->alive = false;
								nodes[j].physical->Object = NULL;
								nodes[j].physical->ObjectIndex = 0;
								nodes[j].physical->XRot = 0;
								nodes[j].physical->YRot = 0;
							}
						}
	
						tempSocks[q] = NULL;
						tempTimeouts[q] = 0;					
					}
				} else {
					tempTimeouts[q]++;
				}
		
				if ( tempTimeouts[q] > Config.Timeout )
				{
					if ( Config.DebugMode ) printf("Temporary Socket Timed Out \n");
					Socket_close( tempSocks[q] );
					tempSocks[q] = NULL;
					tempTimeouts[q] = 0;
				}
			} else {
				if ( Config.DebugMode ) printf("Temporary Socket Disconnected \n");
				Socket_close( tempSocks[q] );
				tempSocks[q] = NULL;
				tempTimeouts[q] = 0;
			}
		}
	}			
	
	if ( Config.DebugMode ) printf("Lost Connections \n");
	// Reconnect with Lost Connections
	int i;
	for ( i = 0; i < MAX_PLAYERS; i++ )
	{
		if ( nodes[i].connected && strcmp(Player1.IP,nodes[i].ip) )
		{
			// Socket Connection Lost!
			if ( !Socket_isConnected( nodes[i].socket ) )
			{
				if ( Config.DebugMode ) printf("Connection lost to IP: %s \n", nodes[i].ip);
				nodes[i].socket = Connect( nodes[i].ip, Config.Port, 1 );
				if ( nodes[i].socket == NULL )
				{
					// A Reconnect Wasnt Possible
					nodes[i].connected = false;
					// Clear the Node's Data
					if (nodes[i].physical->alive)
					{	// Remove the ColCirc from Physics
						World->RemoveCircle( nodes[i].physical->ObjectIndex, false );
						delete nodes[i].physical->Object;
					}
					free(nodes[i].player);
					free(nodes[i].physical);
				} else {
					// If a reconnect was possible, tell the other psp it was a reconnect
					// And re-give it our info
					sprintf( outbuf, "RECONNECT" );
					sprintf( (outbuf + 16), Config.PlayerName );
					memcpy( (outbuf + 48), &Config.PlayerColor, 4 );
					Socket_send( nodes[i].socket, outbuf, Config.BufferSize );
				}
				
			}
		}
	}

	if ( Config.DebugMode ) printf("Checking Messages \n");
	// Check for new messages
	for ( i = 0; i < MAX_PLAYERS; i++ )
	{
		if ( nodes[i].connected && strcmp(Player1.IP, nodes[i].ip) )
		{
			Socket_recv( nodes[i].socket, inbuf, Config.BufferSize );
			
			if (inbuf[0] != '\0')
			{	// Message, check what it is

				if ( Config.DebugMode ) printf("Message from %s \n", nodes[i].player->name);

				// Messages:
				// Shoot	- Tells player shot + bullet info
				// Hit		- Tells player was hit
				// Die		- Tells player died + by who
				// Boxes	- Syncs the Crates between users
				// Info		- Syncs player info for that player
				// Reqall	- A newly joined player wants to know whats going on
				// Byebye	- A Legitimate Disconnect Signal
				if ( strncasecmp( inbuf, "SHOOT", 5 ) == 0 )
				{
					// Decode Bullet info and add it as a bullet
					// Play Shot Sound
					// Add Muzzle flare
				
				}
				else if ( strncasecmp( inbuf, "BYEBYE", 6 ) == 0 )
				{
					// Delete all of it
					if ( nodes[i].physical->alive )
					{
						World->RemoveCircle( nodes[i].physical->ObjectIndex, false );
						delete nodes[i].physical->Object;
					}
					free( nodes[i].physical );
					free( nodes[i].player );

					nodes[i].connected = false;
					Socket_close( nodes[i].socket );

					if ( Config.DebugMode ) printf(" IP: %s gracefully left \n",nodes[i].ip);
				}
				else if ( strncasecmp( inbuf, "HIT", 3 ) == 0 )
				{
					// Make a blood splatter and play a HIt noise
				}
				else if ( strncasecmp( inbuf, "DIE", 3 ) == 0 )
				{
					// Change scores
					// Make Blood + Corpse
					// Play Die Sound
					// Delete ColCircle Object
				}
				else if ( strncasecmp( inbuf, "BOXES", 5 ) == 0 )
				{
					// Compromise:
					// Go through each box and set it's position to the average
					// of the two positions
				}
				else if ( strncasecmp( inbuf, "INFO", 4 ) == 0 )
				{
					if ( Config.DebugMode ) printf( " Info for node[%i] \n", i );
					// Set player's info to this
					// If Alive, make sure you have a ColCircle
					// If Dead, make sure you don't have a ColCircle
					// Format: Name, Color, Kills, Deaths, Alive, X, Y, XRot, YRot
					sprintf( nodes[i].player->name, inbuf+16 );
					memcpy( &nodes[i].player->color, inbuf+48, 4 );
					memcpy( &nodes[i].player->kills, inbuf+52, 2 );
					memcpy( &nodes[i].player->deaths, inbuf+54, 2 );
					memcpy( &nodes[i].physical->alive, inbuf+56, 4 );

					if ( nodes[i].physical->alive )
					{
						// Check for a ColCircle
						if ( nodes[i].physical->Object == NULL )
						{
							// Make it
							nodes[i].physical->Object = new ColCircle;
							nodes[i].physical->Object->kind = 2;
							nodes[i].physical->Object->xsp = 0;
							nodes[i].physical->Object->ysp = 0;
							nodes[i].physical->Object->size = PLAYER_SIZE;
							memcpy( &nodes[i].physical->Object->x, inbuf+60, 4);
							memcpy( &nodes[i].physical->Object->y, inbuf+64, 4);

							// Add it to the physics world
							nodes[i].physical->ObjectIndex = World->AddCircle( nodes[i].physical->Object );
						} else {
							float oldx, oldy;
							oldx = nodes[i].physical->Object->x;
							oldy = nodes[i].physical->Object->y;
							memcpy( &nodes[i].physical->Object->x, inbuf+60, 4);
							memcpy( &nodes[i].physical->Object->y, inbuf+64, 4);
							// Set the speed for it to better interpolate / extrapolate
							nodes[i].physical->Object->xsp = (nodes[i].physical->Object->x - oldx) / PHYSICAL_UPDATE_TIME;
							nodes[i].physical->Object->ysp = (nodes[i].physical->Object->y - oldy) / PHYSICAL_UPDATE_TIME;
						}	
					} else {
						// If it's not alive, check to make sure the ColCircle is gone
						if ( nodes[i].physical->Object != NULL )
						{
							World->RemoveCircle( nodes[i].physical->ObjectIndex, false );
							delete nodes[i].physical->Object;
							nodes[i].physical->Object = NULL;
						}
							
					}
					
					memcpy( &nodes[i].physical->XRot, inbuf+68, 4 );
					memcpy( &nodes[i].physical->YRot, inbuf+72, 4 );


					// Finished Updating with the Info

				}
				else if ( strncasecmp( inbuf, "REQALL1", 7 ) == 0 )
				{	// Need to send GALL1 & GALL2
					if ( Config.DebugMode ) printf("Message is \"REQALL1\" \n");
					sprintf(outbuf,"GALL1");
					short num = 0;
					char* npt = (outbuf+18);
					if ( Config.DebugMode ) printf("Making Send Buffer \n");
					
					int j;
					for ( j = 0; j < MAX_PLAYERS; j++ )
					{
						if ( nodes[j].connected )
						{
							// Only send IP
							// Other Info Can Be Obtained on the Frequent Updates
							if ( Config.DebugMode ) printf("Adding Node #%i \n",j);
							sprintf( (npt), nodes[j].ip );
							num++;
							npt = npt + 16;
						}
					}
					if ( Config.DebugMode ) printf("Sending... \n");
					memcpy( (outbuf+16), &num, sizeof(short));
					Socket_send( nodes[i].socket, outbuf, Config.BufferSize );
				}
				else if ( strncasecmp( inbuf, "REQALL2", 7 ) == 0 )
				{
					if ( Config.DebugMode ) printf("Reqall2... \n");

					// Now send the box info
					sprintf( outbuf, "GALL2" );
					short num = 0;
					char* mem = (outbuf + 18);

					int p;
					for ( p = 0; p < MAX_BOXES; p++ )
					{
						if ( Boxes[p] != NULL )
						{
							num++;
							memcpy( mem, &Boxes[p]->Object->x, 4 );
							memcpy( mem+4, &Boxes[p]->Object->y, 4 );
							mem += 8;
						}
					}

					nodes[i].connected = 2;
					memcpy( outbuf+16, &num, 2 );
					Socket_send( nodes[i].socket, (void*)outbuf, Config.BufferSize );
					if ( Config.DebugMode ) printf("done \n");
					
				}
				// Display it no matter what
				char mess[16];
				sprintf( mess, inbuf );
				if ( Config.DebugMode ) printf("Got message \"%s\" from %s \n", mess, nodes[i].player->name );
			}
		}
	}	


	if ( Config.DebugMode ) printf("Network Timing \n");
	// Network Timing
	Player1.masterServerUpdate -= dt;
	Player1.boxUpdate -= dt;	

	// This is only necessary when the info is changing (player moving/is alive)
	if ( Player1.physical->alive ) Player1.physicalUpdate -= dt;

	
	if ( Player1.masterServerUpdate < 0.0f )
	{
		// Send the master server the newest member list
		Player1.masterServerUpdate = MASTER_SERVER_UPDATE_TIME;
		Socket_close( masterServer );
		
//		if ( masterServer == NULL || !Socket_isConnected(masterServer) )		
		masterServer = Connect( Config.MasterServer, Config.Port, 1 );

		if ( masterServer == NULL || !Socket_isConnected(masterServer) )		
			masterServer = Connect( Config.MasterServer, Config.Port, 1 );			

		// (16)Gameinfo + (2) GameID + (2)CurPlayers + (16) IPaddr
		sprintf( outbuf, "GAMEINFO" );
		memcpy( outbuf+16, &Player1.gameId, 2 );
		char* pt = outbuf + 20;
		short numPlayers;
		int w;
		for ( w = 0; w < MAX_PLAYERS; w++ )
		{
			if ( nodes[w].connected )
			{
				memcpy( pt, nodes[w].ip, 16 );
				pt += 16;
				numPlayers++;
			}
		}
		memcpy( outbuf+18, &numPlayers, 2 );
		
		Socket_send( masterServer, outbuf, Config.BufferSize );

	}

	if ( Player1.boxUpdate < 0.0f )
	{
		Player1.boxUpdate = BOX_UPDATE_TIME;
	}

	if ( Player1.physicalUpdate < 0.0f )
	{
		Player1.physicalUpdate = PHYSICAL_UPDATE_TIME;
		
		// Compile the buffer togethor
		sprintf( outbuf, "INFO" );

		sprintf( outbuf+16, Player1.player->name );
		memcpy( outbuf+48, &Player1.player->color, 4 );
		memcpy( outbuf+52, &Player1.player->kills, 2 );
		memcpy( outbuf+54, &Player1.player->deaths, 2 );

		memcpy( outbuf+56, &Player1.physical->alive, 4 );
		if ( Player1.physical->alive )
		{
			memcpy( outbuf+60, &Player1.physical->Object->x, 4 );
			memcpy( outbuf+64, &Player1.physical->Object->y, 4 );			
		}
		memcpy( outbuf+68, &Player1.physical->XRot, 4 );
		memcpy( outbuf+72, &Player1.physical->YRot, 4 );

		// Send it to everyone
		SendMessage();
	}	
	
	
	return 1;
}

