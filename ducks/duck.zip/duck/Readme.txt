README.txt

 DUCKS - By Team Duck

 Programming By:
	Greg Tourville	(XiGency)
	Matt Thomas	(Slasher)

 Modeling By:
	Greg Tourville	(XiGency)

 Music By:
	Greg Tourville

 Testers:
	RodentHunter59x, AnonymousTipster, Branin5150, FrozenIpaq, dtrinh, ranmax09

Quick Start Guide:
1) Open Config.txt and change PlayerSettings and your Connection #
	Make sure the connection you pick has a static IP
2) Forward Port 1515 to your PSP's IP address
3) Copy over the Eboot to your PSP and run
4) Either pick a server or create a new one
5) Slaughter some ducks
6) In order to change servers or settings, you must exit and re-run the game


For Help:
Check out www.teamduck.game-host.org for an updated FAQ

