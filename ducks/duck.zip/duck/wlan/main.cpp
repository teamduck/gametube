/////////////////////////////////
// Test
////
// August 8th, 2006
/////////////////////////////////
// Coder: Slasher & Xigency
/////////////////////////////////

///////////// INCLUDES //////////////

#include <pspkernel.h>
#include <pspdisplay.h>
#include <pspdebug.h>
#include <pspsdk.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <pspctrl.h>

// Wlan
#include "wlan.h"

//////////// DEFINES ///////////////

#define 	printf		pspDebugScreenPrintf 

#define 	BUFFER_SIZE	256
#define		MAX_NODES	16

//#define		NAME		"XiGency"
//#define		NAME		"Youresam"
//#define		NAME		"rodenthunter"
//#define		NAME		"mjfmurray"
#define		NAME		"LizardKing"
//#define		NAME		"djdanff"

#define		SERVER		"www.teamduck.game-host.org"
//#define		SERVER		"192.168.1.99"
//#define		SERVER		"www.luaplayer.org"
#define		PORT		1515

#define		TEMP_TIMEOUT	100
#define		NUM_TEMP_SOCKS	5

// Module info
PSP_MODULE_INFO("Wlan Test", 0x1000,1,1);
PSP_MAIN_THREAD_ATTR(0);
//PSP_HEAP_SIZE_KB(1024);		// 1 mb


// IP Storage
char	ip[16];			// My IP
short	gameId;

// Node structure
struct Node
{
	bool connected;
	char ip[16];
	Socket* socket;
	char name[32];
};

// Node list
Node	nodes[MAX_NODES];

Socket* masterServer;

char* outbuf;
char* inbuf;


/* Exit callback */
int exit_callback(int arg1, int arg2, void *common)
{
	sceKernelExitGame();
	return 0;
}

/* Callback thread */
int CallbackThread(SceSize args, void *argp)
{
	int cbid;
	cbid = sceKernelCreateCallback("Exit Callback", exit_callback, NULL);
	sceKernelRegisterExitCallback(cbid);
	sceKernelSleepThreadCB();
	return 0;
}

/* Sets up the callback thread and returns its thread id */
int SetupCallbacks(void)
{
	int thid = 0;
	thid = sceKernelCreateThread("update_thread", CallbackThread, 0x11, 0xFA0, 0, 0);
	if(thid >= 0) sceKernelStartThread(thid, 0, 0);
	return thid;
}

int server_failed()
{
	printf("Connection to server Failed \n");		
	sceKernelDelayThread(2000*1000); // 2000ms
	return 0;
}

Socket*	Connect( const char* Server, int Port, int Tries )
{
	Socket* sock;

	int j;
	for ( j = 0; j < Tries; j++ )
	{
		// Initial Connect
		sock = Socket_connect(Server,Port);
		if ( sock == NULL ) return NULL;
	
		// Try for 1 second
		int i;
		for ( i = 0; i < 20; i++ )
		{
			if (Socket_isConnected(sock)) break;
			sceKernelDelayThread(50*1000);
		}

		sceKernelDelayThread(50*1000);	

		// If it worked, return the socket
		if (Socket_isConnected(sock))
		{
			return sock;
		} 

		// Other wise, delete the socket & try again
		Socket_close(sock);
	}
	
	// Failed
	return NULL;
}

int	game()
{

	SceCtrlData pad, old;

	// Create Listen Socket
	Socket*	listenSock;
	Socket* tempSocks[NUM_TEMP_SOCKS];
	int	tempTimeouts[NUM_TEMP_SOCKS];
	
	int q;
	for ( q = 0; q < NUM_TEMP_SOCKS; q++ )
	{
		tempSocks[q] = NULL;
		tempTimeouts[q] = 0;
	}


	
	listenSock = Socket_createServerSocket(PORT);

	if (listenSock == NULL)
	{
		printf("Couldn't Create Server Socket!");
		sceKernelDelayThread(2000*1000); // 2000ms
		return 0;
	}

	printf("Server Socket Open \n");
		

	// Loop
	for (;;)
	{

		old = pad;
		sceCtrlSetSamplingCycle(0);
 		sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
 		sceCtrlReadBufferPositive(&pad, 1);		
		
		
		// Accept new connection
		for ( q = 0; q < NUM_TEMP_SOCKS; q++ )
		{
			if ( tempSocks[q] == NULL )
			{
				tempSocks[q] = Socket_accept(listenSock);
				if ( tempSocks[q] != NULL )
				{
					printf("New Connection \n");
				}
			} else {
				if ( Socket_isConnected( tempSocks[q] ) )
				{
					//memset(inbuf, 0, BUFFER_SIZE);
					Socket_recv( tempSocks[q], inbuf, BUFFER_SIZE );
					if (inbuf[0] != '\0')
					{
						if (strncasecmp(inbuf,"IJOIN", 5)==0)
						{
							// They're Joining, add them as a node
							int i;
							for ( i = 0; i < MAX_NODES; i++ )
							{
								if (nodes[i].connected == false) break;
							}
		
							nodes[i].connected = true;
							sprintf(nodes[i].ip,Socket_toString(tempSocks[q]));
							printf("New Node IP: %s \n", nodes[i].ip);
							nodes[i].socket = tempSocks[q];
							tempSocks[q] = NULL;
							tempTimeouts[q] = 0;
							sprintf(nodes[i].name, (inbuf+16));
							printf("New Node Name: %s \n",nodes[i].name);
						} else if ( strncasecmp(inbuf, "RECONNECT", 9)==0) {
							char tempIp[16];
							sprintf( tempIp, Socket_toString(tempSocks[q]));
							
							// Check to see if we already have them as a node
							// By searching for tempIp in the nodes
							int j;
							for ( j = 0; j < MAX_NODES; j++ )
							{
								if ( nodes[j].connected == true )
								{
									if ( strcmp(nodes[j].ip,tempIp) == 0 )
										break;
								}
							}
							
							// If we do, update the socket with the working one
							if ( j < MAX_NODES )
							{
								nodes[j].socket = tempSocks[q];
							} else {
								// If we don't, make a new node
								for ( j = 0; j < MAX_NODES; j++ )
								{
									if ( nodes[j].connected == false ) break;
								}
		
								nodes[j].connected = true;
								nodes[j].socket = tempSocks[q];
								sprintf(nodes[j].ip,tempIp);
								sprintf(nodes[j].name,(inbuf+16));
								printf(" Node %s reconnected \n", nodes[j].name);
							}
		
							tempSocks[q] = NULL;
							tempTimeouts[q] = 0;					
						}
					} else {
						tempTimeouts[q]++;
					}
		
					if ( tempTimeouts[q] > TEMP_TIMEOUT )
					{
						printf("Temporary Socket Timed Out \n");					
						Socket_close( tempSocks[q] );
						tempSocks[q] = NULL;
						tempTimeouts[q] = 0;
					}
				} else {
					printf("Temporary Socket Disconnected \n");
					Socket_close( tempSocks[q] );
					tempSocks[q] = NULL;
					tempTimeouts[q] = 0;
				}
			}
		}

		// Check Connections
		int i;
		for ( i = 0; i < MAX_NODES; i++ )
		{
			if ( nodes[i].connected && strcmp(ip,nodes[i].ip) )
			{
				// Socket Connection Lost!
				if ( !Socket_isConnected( nodes[i].socket ) )
				{
					printf("Connection lost to IP: %s \n", nodes[i].ip);
					nodes[i].socket = Connect( nodes[i].ip, PORT, 1 );
					if ( nodes[i].socket == NULL )
					{
						// A Reconnect Wasnt Possible
						nodes[i].connected = false;
					} else {
						// If a reconnect was possible, tell the other psp it was a reconnect
						// And re-give it our info
						sprintf( outbuf, "RECONNECT" );
						int bytes = sprintf( (outbuf + 16), NAME ) + 17;
						Socket_send( nodes[i].socket, outbuf, bytes );
					}
					
				}
			}
		}

		// Check Messages
		for ( i = 0; i < MAX_NODES; i++ )
		{
			if ( nodes[i].connected && strcmp(ip,nodes[i].ip) )
			{
				Socket_recv( nodes[i].socket, inbuf, BUFFER_SIZE );
				if (inbuf[0] != '\0')
				{	// Message, check what it is
					// Only vital message as of now is "REQALL"

					printf("Message from %s \n", nodes[i].name);
					if ( strncasecmp( inbuf, "REQALL", 6 ) == 0 )
					{
						printf("Message is \"REQALL\" \n");
						sprintf(outbuf,"GALL");
						short num = 0;
						char* npt = (outbuf+18);

						printf("Making Send Buffer \n");
						int j;
						for ( j = 0; j < MAX_NODES; j++ )
						{
							if ( nodes[j].connected )
							{
								printf("Adding Node #%i \n",j);
								//memcpy( npt, &nodes[i], sizeof(Node) );
								sprintf( ((Node*)npt)->name, nodes[i].name );
								sprintf( ((Node*)npt)->ip, nodes[i].ip );
								num++;
								npt = npt + sizeof(Node);
							}
						}
						printf("Sending... \n");
						memcpy( (outbuf+16), &num, sizeof(short));
						Socket_send( nodes[i].socket, outbuf, BUFFER_SIZE );
						free(outbuf);
					}

					// Display it no matter what
					char mess[16];
					sprintf( mess, inbuf );
					printf("Got message \"%s\" from %s \n", mess, nodes[i].name );
				}
			}
		}
		
		// Check Input / Broadcast Message
		if ( pad.Buttons & PSP_CTRL_CROSS && !( old.Buttons & PSP_CTRL_CROSS ))
		{
			// Send everyone the message
			sprintf(outbuf,"I Pressed Cross");
			printf(outbuf);
			
			for ( i = 0; i < MAX_NODES; i++ )
				if ( nodes[i].connected && strcmp(ip,nodes[i].ip) )
					Socket_send( nodes[i].socket, outbuf, BUFFER_SIZE );
		}
		if ( pad.Buttons & PSP_CTRL_CIRCLE && !( old.Buttons & PSP_CTRL_CIRCLE ))
		{
			// Send everyone the message
			sprintf(outbuf,"I Pressed Circl");
			printf(outbuf);
			
			for ( i = 0; i < MAX_NODES; i++ )
				if ( nodes[i].connected && strcmp(ip,nodes[i].ip) )
					Socket_send( nodes[i].socket, outbuf, BUFFER_SIZE );
		}	
		if ( pad.Buttons & PSP_CTRL_START )
		{
			break;
		}

	}


	return 1;
}

int	newGame()
{
	
	printf("Making new game \n");
	sceKernelDelayThread(200*1000);
	printf("Requesting new game \n");
	
	// If the Connection is lost
	if ( !Socket_isConnected(masterServer) )
	{	// Retry it 3 times
		masterServer = Connect( SERVER, PORT, 3 );
		// If that fails, quit
		if (masterServer == NULL)
			return 0;
	}
	
	sceKernelDelayThread(200*1000);
	sprintf( outbuf, "NEWGAME" );	
	
	int bytes = Socket_send( masterServer, (void*)outbuf, BUFFER_SIZE );
	if ( bytes < sizeof("NEWGAME") )	// If the message didnt get sent, try again
	{
		printf("Message wasn't sent whole \n");
		// If the Connection is lost
		if ( !Socket_isConnected(masterServer) )
		{	// Retry it 3 times
			masterServer = Connect( SERVER, PORT, 3 );
			// If that fails, quit
			if (masterServer == NULL)
				return 0;
		}
		Socket_send( masterServer, (void*)outbuf, 16 );		
	}
	
	printf("Waiting for Game Id message \n");	
		
	// Wait for Game ID #
	for(;;)
	{
		Socket_recv( masterServer, (void*)inbuf, BUFFER_SIZE );
		
		if (inbuf[0] != '\0')
		{
			if (strncasecmp(inbuf,"SERVID", 6)==0)
			{
				memcpy(&gameId,inbuf+16,2);
				printf("Game ID is %i \n", (int)(gameId));
				break;
			}
		}

		sceKernelDelayThread(200*1000);		
		
		// If the Connection is lost
		if ( !Socket_isConnected(masterServer) )
		{	// Retry it 3 times
			masterServer = Connect( SERVER, PORT, 3 );
			// If that fails, quit
			if (masterServer == NULL)
				return 0;
		}		
	}

	
	// Setup the "game"
	int i;
	for ( i = 0; i < MAX_NODES; i++ )
		nodes[i].connected = false;

	// Add self
	sprintf(nodes[0].ip,ip);
	sprintf(nodes[0].name,NAME);
	nodes[0].connected = true;
	
	// Enter Main Loop
	printf("Create Success, Entering Game \n");
	game();
	// Every 1 second connect to the master server, and update info on this game
	
	return 1;
}

int	joinGame( short num )
{
	
	printf("Joining Game #%i \n",(int)num);

	printf("Requesting Member List \n");
	
	// Request A Member List for the Game
	sprintf(outbuf, "IPTABLE");
	memcpy( (outbuf+16), &num, 2 );	// Add the game ID#
	
	sceKernelDelayThread(200*1000);
	
	// If the Connection is lost
	if ( !Socket_isConnected(masterServer) )
	{	// Retry it 3 times
		masterServer = Connect( SERVER, PORT, 3 );
		// If that fails, quit
		if (masterServer == NULL)
			return 0;
	}	
	
	Socket_send( masterServer, (void*)outbuf, BUFFER_SIZE );	

	// Table for retrieved IP's
	short numips;
	char ips[MAX_NODES][16];
	
	// Loop for response
	for(;;)
	{
		Socket_recv( masterServer, (void*)inbuf, BUFFER_SIZE );
		if (inbuf[0] != '\0')
		{
			if (strncasecmp(inbuf,"TABLE", 5)==0)
			{
				memcpy(&numips,inbuf+16,2);
				char* mem = inbuf + 16 + 2;
				printf("Found %i possible nodes \n", (int)numips);
				int i;
				// Clear them
				for ( i = 0; i < MAX_NODES; i++ )
					ips[i][0] = '\0';
				
				// Fill them
				for ( i = 0; i < numips; i++ )
				{
					memcpy(ips[i], mem, 16);
					mem += 16;
				}
				
				break;
			}
		}

		sceKernelDelayThread(200*1000);			
		
		// If the Connection is lost
		if ( !Socket_isConnected(masterServer) )
		{	// Retry it 3 times
			masterServer = Connect( SERVER, PORT, 3 );
			// If that fails, quit
			if (masterServer == NULL)
				return 0;

			// Resend our request (since the server disconnected us probably)
			Socket_send( masterServer, (void*)outbuf, 18 );				
		}		
	}

	printf("Joining Members \n");	

	// Create the temporary sockets
	Socket*	socks[MAX_NODES];
	int i;
	for ( i = 0; i < MAX_NODES; i++ )
		socks[i] = NULL;


	// Clear the real node list
	for ( i = 0; i < MAX_NODES; i++ )
		nodes[i].connected = false;
	
	// Send each a "IJOIN"
	// If you get a response, then turn it into a node
	// When REQALL data arrives, look for any new nodes
	// And connect to them
	
	int reqall = -1;
	int numWork = 0;

	// Connect to each potential
	for ( i = 0; i < MAX_NODES; i++ )
	{
		if ( strlen(ips[i]) > 6 )
		{
			// Give it 3 tries
			printf( "Trying: %s \n", ips[i] );
			socks[i] = Connect(ips[i], PORT, 3);
			
			// Connection Established
			if ( socks[i] != NULL )
			{
				// Count it
				numWork++;
				
				// Add it as a real node
				int j;
				for ( j = 0; j < MAX_NODES; j++ )
				{
					if ( nodes[j].connected == false )
					{
						nodes[j].connected = true;
						sprintf(nodes[j].ip, ips[i]);
						nodes[j].socket = socks[i];
						break;
					}
				}

				// This is the node we ask for all the info
				// We want it to be the last node we talk to
				// So that the connection is less likely to
				// have timed out.
				reqall = j;
				
				// Give it an IJOIN signal + Your Name
				sprintf( outbuf, "IJOIN" );
				sprintf( (outbuf+16), NAME );
				Socket_send(socks[i], (void*)outbuf, BUFFER_SIZE );

			}
		}
	}

	// No Successful Connections
	if ( numWork == 0 )
	{
		printf("No Successful Connections to Nodes \n");
		return 0;
	}

	// If its not connected, re-connect with it
	if ( !Socket_isConnected(nodes[reqall].socket ) )
	{
		nodes[reqall].socket = Connect( nodes[reqall].ip, PORT, 3 );
		// Failure, could not connect with Reqall Node
		if ( nodes[reqall].socket == NULL )
		{
			printf("Could not connect to Reqall Node \n");
			return 0;
		}
	}
	
	// Requesting Game Info from our favorite Node
	printf("Requesting Game Info with REQALL \n");	
	sprintf( outbuf, "REQALL" );
	Socket_send( nodes[reqall].socket, outbuf, BUFFER_SIZE );
			

	// Loop for response
	for(;;)
	{
		Socket_recv( nodes[reqall].socket, (void*)inbuf, BUFFER_SIZE );
		if (inbuf[0] != '\0')
		{
			printf("Message from REQALL \n");
			if (strncasecmp(inbuf,"GALL", 4)==0)
			{
				short num;
				memcpy(&num,inbuf+16,2);
				char* memnode = (inbuf+16+2);
				Node lnode;

				for ( i = 0; i < num; i++ )
				{
					printf("Checking node %i of %i \n", (i+1), (int)num);
					memcpy( &lnode, memnode, sizeof(Node));
					memnode = memnode + sizeof(Node);

					// If it isn't ourselves, then add it
					if ( strcmp(lnode.ip,ip) )
					{
						// Look for IP
						int u;
						for ( u = 0; u < MAX_NODES; u++ )
						{
							if ( strcmp(nodes[u].ip,lnode.ip) == 0 )
								break;
						}
						if ( u == MAX_NODES )
						{
							// If we don't have it
							// Add it and connect to it
							int l;
							for ( l = 0; l < MAX_NODES; l++ )
								if ( nodes[l].connected == false ) break;

							sprintf(nodes[l].ip, lnode.ip);
							sprintf(nodes[l].name, lnode.name);
							nodes[l].socket = Connect( nodes[l].ip, PORT, 3 );
							
							if ( nodes[l].socket )	// If it connected, tell us
							{			
								printf( " Node %s has connected \n", nodes[l].name );
								nodes[l].connected = true;
							} else {				// Otherwise, ignore it for now (Serious Error, Later)
								printf( " Couldn't Connect to Node %s \n", nodes[l].name );
								nodes[l].connected = false;
							}
						} else {
							// If we already have it, just get the name
							// Get the name
							sprintf( nodes[u].name, lnode.name );
							// And tell us about it
							printf( " Node %s has connected \n", nodes[u].name );
						}
					} else {
						// If its us, plug us in
						int l;
						for ( l = 0; l < MAX_NODES; l++ )
							if ( nodes[l].connected == false ) break;

						sprintf( nodes[l].name, NAME );
						sprintf( nodes[l].ip, ip );
						nodes[l].connected = true;
						nodes[l].socket = NULL;
					}
				}

				
				break;
			}
		}

		// Short Delay
		sceKernelDelayThread(50*1000);

		// If its not connected, re-connect with it
		if ( !Socket_isConnected(nodes[reqall].socket ) )
		{
			nodes[reqall].socket = Connect( nodes[reqall].ip, PORT, 3 );
			// Failure, could not connect with Reqall Node
			if ( nodes[reqall].socket == NULL )
			{
				printf("Disconnected from Reqall Node \n");
				return 0;
			}
		}			
	}	
	
	// And Then Enter Main Loop
	printf("Join Success, Entering Game! \n");
	game();

	return 1;
}


///////////// MAIN FUNCTION /////////////////
int user_main( SceSize argc, void *argp )
{ 
	outbuf = (char*)malloc(sizeof(char)*BUFFER_SIZE);
	inbuf = (char*)malloc(sizeof(char)*BUFFER_SIZE);

	printf("WLAN Test \n");
	printf("Initing Wlan \n");

	if (!Wlan_init())
	{
		printf("Init failed");
		sceKernelDelayThread(2000*1000); // 2000ms
		return 0;
	}	
		
	
	printf("Connecting to connection 1 \n");

	if (Wlan_useConnectionConfig(0)==0)
	{
		printf("Connection failed");
		sceKernelDelayThread(2000*1000); // 2000ms
		return 0;
	}

	printf("Connected with IP of: %s \n", Wlan_getIPAddress());

	masterServer = Connect( SERVER, PORT, 3 );
	if ( masterServer == NULL )
	{
		server_failed();
		return 0;
	}

	printf("Connected to server \n");

	// Ask whats my ip
	sprintf( outbuf, "MYIP" );
	Socket_send( masterServer, (void*)outbuf, BUFFER_SIZE );

	sprintf( outbuf, "PING" );
	Socket_send( masterServer, (void*)outbuf, BUFFER_SIZE );

	sprintf( outbuf, "PONG" );
	Socket_send( masterServer, (void*)outbuf, BUFFER_SIZE );	

	sprintf( outbuf, "PING" );
	Socket_send( masterServer, (void*)outbuf, BUFFER_SIZE );

	sprintf( outbuf, "MYIP" );
	Socket_send( masterServer, (void*)outbuf, BUFFER_SIZE );	

	// Wait for IP, then disconnect
	for(;;)
	{
	
		Socket_recv( masterServer, (void*)inbuf, BUFFER_SIZE );
		if (inbuf[0] != '\0')
		{
			printf( inbuf );
			if (strncasecmp(inbuf,"YOURIP", 6)==0)
			{
				memcpy(ip,inbuf+16,16);
				break;
			}
		}
		
		sceKernelDelayThread(50*1000);

		// If the Connection is lost
		if ( !Socket_isConnected(masterServer) )
		{	// Retry it 3 times
			masterServer = Connect( SERVER, PORT, 3 );
			// If that fails, quit
			if (masterServer == NULL)
				return 0;
		}
	}

	// Found IP from the Server
	printf( "Your IP is %s \n", ip );

	// Ask for the Game List
	// (Make sure the connection didnt timeout)
	sprintf( outbuf, "REFRESH" );
	if ( Socket_isConnected( masterServer ) )
	{
		Socket_send( masterServer, (void*)outbuf, BUFFER_SIZE );
	} else {
		masterServer = Connect( SERVER, PORT, 3 );
		if ( masterServer != NULL )
		{
			Socket_send( masterServer, (void*)outbuf, BUFFER_SIZE );			
		} else {
			return 0;
		}
	}
		

	// Wait for list
	for(;;)
	{
		Socket_recv( masterServer, (void*)inbuf, BUFFER_SIZE );
		if (inbuf[0] != '\0')
		{
			if (strncasecmp(inbuf,"LIST", 4)==0)
			{
				printf("Got List \n");
				
				// Decode the list
				// Find # of games
				short num;
				memcpy( &num, inbuf+16, sizeof(short) );
				// If 0 then make a new one
				if ( num == 0 ) newGame();
				
				// Else, join the first one
				// Find its ID
				memcpy( &num, inbuf+16+2, sizeof(short) );
				joinGame( num );
				
				break;
			}
		}
	
		sceKernelDelayThread(50*1000);

		// If the Connection is lost
		if ( !Socket_isConnected(masterServer) )
		{	// Retry it 3 times
			masterServer = Connect( SERVER, PORT, 3 );
			// If that fails, quit
			if (masterServer == NULL)
				return 0;
		}		
	}	



	// Done
	Wlan_term();

	free((void*)inbuf);
	free((void*)outbuf);
	
	return 1;
}


/* Simple thread */
int main(int argc, char **argv)
{
	// Initiate
	SetupCallbacks();
	pspDebugScreenInit();
	
	printf("Loading inet modules\n");
	if(pspSdkLoadInetModules() < 0)
	{
		printf("Error, could not load inet modules\n");
		sceKernelDelayThread(2000*1000);
		sceKernelExitGame();
	}
	
	// create user thread, tweek stack size here if necessary
	int thid = sceKernelCreateThread("User Mode Thread", user_main,
	    0x11, // default priority
	    256 * 1024, // stack size (256KB is regular default)
	    PSP_THREAD_ATTR_USER, NULL);
	
	// start user thread, then wait for it to do everything else
	sceKernelStartThread(thid, 0, NULL);
	sceKernelWaitThreadEnd(thid, NULL);

	sceKernelExitGame();
	return 0;
}
