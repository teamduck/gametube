// WLAN - Original code from Luaplayer
// Based off of PSPpet's work
// Converted By Greg Tourville


#include <pspsdk.h>
#include <psputility.h>
#include <pspnet_apctl.h>
//#include <pspnet_resolver.h>
//#include <pspnet_inet.h>
//#include <sys\socket.h>
#include <malloc.h>
#include <stdio.h>

extern "C" {
#include "my_socket.h"
}

#define SOCKET int

#define MAX_PICK 5

bool wlanInitialized = false;
char resolverBuffer[1024];
int resolverId;

typedef struct
{
	SOCKET sock;
	struct sockaddr_in addrTo;
	bool serverSocket;
} Socket;

struct Pick
{
	int index;
	char name[64];
};
Pick picks[MAX_PICK];
int pick_count = 0;

// hack: this should be moved to PSPSDK, but by someone who knows how to do the in_addr mess the right way :-)
extern "C" {
	
int sceNetResolverCreate(int *rid, void *buf, SceSize buflen);
int sceNetResolverStartNtoA(int rid, const char *hostname, u32* in_addr, unsigned int timeout, int retry);
int sceNetResolverStartAtoN(int rid, const u32* in_addr, char *hostname, SceSize hostname_len, unsigned int timeout, int retry);
int sceNetResolverStop(int rid);
int sceNetInetInetAton(const char* host, u32* in_addr);

}


int Wlan_init()
{
	if (wlanInitialized) return 1;
	int err = pspSdkInetInit();
	
	if (err != 0) return 0;
	
	err = sceNetResolverCreate(&resolverId, resolverBuffer, sizeof(resolverBuffer));
	wlanInitialized = true;
	return 1;
}

int Wlan_term()
{
	// TODO: doesn't term; another call to pspSdkInetInit fails
	if (!wlanInitialized) return 1;
	sceNetApctlDisconnect();
	pspSdkInetTerm();
	wlanInitialized = false;
	return 1;
}

int Wlan_getConnectionConfigs()
{
	
	int iNetIndex;
	for (iNetIndex = 1; iNetIndex < 100; iNetIndex++) // skip the 0th connection
	{
		if (sceUtilityCheckNetParam(iNetIndex) != 0) break;  // no more
		sceUtilityGetNetParam(iNetIndex, 0, (netData*) picks[pick_count].name);
		picks[pick_count].index = iNetIndex;
		pick_count++;
		if (pick_count >= MAX_PICK) break;  // no more room
	}

	return 1;
}

int Wlan_useConnectionConfig(int connectionConfig)
{
	if (!wlanInitialized) return 0;
	
	int result = sceNetApctlConnect(connectionConfig); 
	
	int state = 0; 
	
	while (1) { 
		sceKernelDelayThread(200*1000); // 200ms 
		
		int err = sceNetApctlGetState(&state); 
		if (err != 0 || state == 0) {
			// connection failed
			return 0; 
		}
		
		if (state == 4) {
			//connection succeeded 
			result = 1; 
			break; 
		} 
	} 
	
	return 1; 
}

char* Wlan_getIPAddress()
{
	if (!wlanInitialized) return 0;

	char* szMyIPAddr = new char[32];
	if (sceNetApctlGetInfo(8, szMyIPAddr) != 0) return NULL;
	return szMyIPAddr;
}

int Socket_free(Socket* socket)
{
	sceNetInetClose(socket->sock);
	free(socket);
	return 1;
}

unsigned short htons(unsigned short wIn)
{
    u8 bHi = (wIn >> 8) & 0xFF;
    u8 bLo = wIn & 0xFF;
    return ((unsigned short)bLo << 8) | bHi;
}


int setSockNoBlock(SOCKET s, u32 val)
{ 
    return sceNetInetSetsockopt(s, SOL_SOCKET, 0x1009, (const char*)&val, sizeof(u32));
}

Socket* Socket_connect(const char* host, int port)
{
	if (!wlanInitialized) return NULL; 
	
	// 50 ms
	sceKernelDelayThread(50*1000); // without this delay it doesn't work sometime

	Socket* socket = (Socket*) malloc(sizeof(Socket));
	socket->serverSocket = false;

	// resolve host
	socket->addrTo.sin_family = AF_INET;
	socket->addrTo.sin_port = htons(port);
	int err = sceNetInetInetAton(host, (u32*)&socket->addrTo.sin_addr);
	if (err == 0) {
		err = sceNetResolverStartNtoA(resolverId, host, &socket->addrTo.sin_addr, 2, 3);
		// DNS did not resolve
		if (err < 0) return NULL;
	}

	// create non-blocking socket	
	socket->sock = sceNetInetSocket(AF_INET, SOCK_STREAM, 0);

	// Invalid socket
	if (socket->sock & 0x80000000) {
		return NULL; 
	}
	setSockNoBlock(socket->sock, 1);
	
	// connect
	err = sceNetInetConnect(socket->sock, &socket->addrTo, sizeof(socket->addrTo));
	
//	int inetErr = 
	sceNetInetGetErrno();
//	if (err != 0 /* && inetErr != 0x77 */ ) {  // returns 0x7d, I don't know why
//		return NULL;
//	}

	return socket;
}

int Socket_isConnected(Socket* socket)
{
	if (!wlanInitialized) return 0;

	if (socket->serverSocket) {
		return 1;
	}

	// try connect again, which should always fail
	// look at why it failed to figure out if it is connected
	//REVIEW: a conceptually cleaner way to poll this?? (accept?)
	int err = sceNetInetConnect(socket->sock, &socket->addrTo, sizeof(socket->addrTo));
	if (err == 0 || (err == -1 && sceNetInetGetErrno() == 0x7F)) {
		// now connected - I hope
		return 1;
	}

	return 0;
}

Socket* Socket_createServerSocket(int port)
{
	if (!wlanInitialized) return NULL;
	
	Socket* socket = (Socket*) malloc(sizeof(Socket));
	socket->serverSocket = true;
	
        socket->sock = sceNetInetSocket(AF_INET, SOCK_STREAM, 0);
        if (socket->sock <= 0) {
		return NULL; 
        }

        socket->addrTo.sin_family = AF_INET;
        socket->addrTo.sin_port = htons(port);
        socket->addrTo.sin_addr = 0;

        int err = sceNetInetBind(socket->sock, &socket->addrTo, sizeof(socket->addrTo));
        if (err != 0) {
		return NULL; 
        }

	setSockNoBlock(socket->sock, 1);

        err = sceNetInetListen(socket->sock, 1);
        if (err != 0) {
		return NULL; 
        }
        
        return socket;
}

Socket* Socket_accept(Socket* socket)
{
	if (!wlanInitialized) return NULL;
	if (!socket->serverSocket) return NULL;

	// check for waiting incoming connections
        struct sockaddr_in addrAccept;
        int cbAddrAccept = sizeof(addrAccept);
        SOCKET sockClient = sceNetInetAccept(socket->sock, &addrAccept, &cbAddrAccept);
        if (sockClient <= 0) {
        	return NULL;
        }

	// create new socket
	Socket* incomingSocket = (Socket*) malloc(sizeof(Socket));
	incomingSocket->serverSocket = false;
	incomingSocket->sock = sockClient;
	incomingSocket->addrTo = addrAccept;

	return incomingSocket;
}

int Socket_recv(Socket* socket, void* buffer, size_t bytes)
{
	if (!wlanInitialized) return 0;

	if (socket->serverSocket) return 0;

	int count = sceNetInetRecv(socket->sock, (u8*)buffer, bytes, 0);
	if (count <= 0) {			
		*((char*)buffer) = 0;
	}					
	return 1;
}

int Socket_send(Socket* socket, const void* buffer, size_t bytes)
{
	if (!wlanInitialized) return 0;
	if (socket->serverSocket) return 0;

	int result = sceNetInetSend(socket->sock, buffer, bytes, 0);
	return result;
}

int Socket_close(Socket* socket)
{
	if (!wlanInitialized) return 0;
	sceNetInetClose(socket->sock);
	return 1;
}

char* Socket_toString(Socket* socket)
{
	char* buf = new char[128];
	sprintf(buf, "%i.%i.%i.%i",
		socket->addrTo.sin_addr & 255,
		(socket->addrTo.sin_addr >> 8) & 255,
		(socket->addrTo.sin_addr >> 16) & 255,
		(socket->addrTo.sin_addr >> 24) & 255);
	return buf;
}

