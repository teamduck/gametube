/*	Greg Tourville's Original Physics Engine
 *	Copyright 2006 Greg Tourville
 *	August 9th, 2006
 *	----------------------------
 *	By Greg aka XiGency
**/

// #define		toRads		(3.14/180)
#define		toRads			(0.017444)
#define		toDeg			(180/3.14)

// Performance Related Definitions

// Per Class Maximums
#define		MAX_CIRCLES			400
#define		MAX_WALLS			1000
//#define		MAX_STATCIRCLES		100
#define		MAX_HINGES			20
#define		MAX_PARTICLES		200

// Per Section Struct Maximums
#define		SECTION_WALLS		20
#define		SECTION_HINGES		5
// #define		SECTION_CIRCLES		5

#define		MAX_SECTIONS_X		30
#define		MAX_SECTIONS_Y		30


// Flag Definitions
#define CIRC_FAKE_ROT		// Rotates Circles based on xspeed
#define CIRC_FAKE_BOUNCE	// Uses my (less accurate and less optimized) bounce code
							// Otherwise uses real pool code (non existant as of yet)


// Screen Definition
#ifndef SCR_WIDTH
	#define SCR_WIDTH		480
#endif
#ifndef SCR_HEIGHT	
	#define SCR_HEIGHT		272
#endif

// Timing Globals
//double thisTime;
//double oldTime;
//double dt;
//double fps;

// Collision Objects
// Table of Collisions:
//				Circ	Wall	Hinge	Particle	StatCirc
// Circ			X		x		X		x			x
// Wall
// StatCirc
// Hinge						X?		x
// Particle				x							x
//

// Bounding Circles (Rigid w/ Rotation)
struct ColCircle
{
	int	kind;	// Kind 0 = Box, 1 = Player1, 2 = Net Player

	float	x, y;
	float	xsp, ysp;
//	float	rot, rotsp;
//	int	id;
	float	size;
//	float	mass;
};

// Static Bounding Circles (Rigid)
/*
struct ColStatCircle
{
	int		x, y;
	int		size;
};
*/

// Static Bounding Line (Rigid)
struct ColWall
{
	float x1, y1;
	float x2, y2;
	float size;
};

// Static Bounding Line (Rigid w/ Rotation)
struct ColHinge
{
	int side1, side2, size;
	int x, y;
	float rot, rotsp;
	int x1, y1, x2, y2;
};

// Point w/ Velocity
struct ColParticle
{
	float x, y;
	float xsp, ysp;
	float life, time;
};

// Small Partitions of Walls, Hinges, and StatCircles (and other things that dont move)
struct Section
{
	ColWall*		Walls[SECTION_WALLS];
	ColHinge*		Hinges[SECTION_HINGES];
//	ColStatCircles*	Circles[SECTION_CIRCLES];
};

int	clearSection( Section* s );

class Physics
{
public:
	/*		DATA		*/

	// Global Boundries
	int SCREEN_WIDTH;
	int SCREEN_HEIGHT;

	int LEFT_X;
	int RIGHT_X;
	int UPPER_Y;
	int LOWER_Y;

	// Options
	float	FRICTION;
	float	GRAVITY;
	float	GRAVITY_ANGLE;
	float	LOSS_OF_ENERGY;

	// Section Settings
	int		SectionWidth;
	int		SectionHeight;
	int		SectionsX;
	int		SectionsY;

	/*		OBJECTS		*/

	// Sectioned Lists of Statics
	Section*		Sections[MAX_SECTIONS_X][MAX_SECTIONS_Y];

	// Complete Lists
	ColCircle*		Circles[MAX_CIRCLES];
	ColWall*		Walls[MAX_WALLS];
	ColHinge*		Hinges[MAX_HINGES];
	ColParticle*	Particles[MAX_PARTICLES];
//	ColStatCircle*	StatCircles[MAX_STATCIRCLES];

	/*		FUNCTIONS	*/

	// Constructor & Deconstructor
	Physics();
	~Physics();

	// Initialize - Sets the Engine to a mode where it is "Live"
	// and Updates can be called without danger
	int Initialize();	// Divisions Sections, Sorts everything

	// Update Functions
	int GlobalUpdate( double dt );

	// Object Management Functions
	int AddCircle( ColCircle* source );		// Pass a struct* and added to list, returns index
	int RemoveCircle( int index, bool del );			// By nID
	
	int AddWall( ColWall* source );			// Pass a struct* and added to list, returns index
	int RemoveWall( int index, bool del );			// By index

	int AddHinge( ColHinge* source );
	int RemoveHinge( int index, bool del );

	int AddParticle( ColParticle* source );

//	int	AddStatCircle( ColStatCircle* source );
//	int RemoveStatCircle( int index, bool del );



protected:
	// Update Functions
	int CircleUpdate( double dt );
	int HingeUpdate( double dt );

	int Physics::circleUpdate( ColCircle* b, double dt );
	int Physics::circleWallCollision( ColCircle* b, ColWall* w );
	int Physics::circleCircleCollision( ColCircle* r, ColCircle* b );

	// ID Number
	int nid;
	int frameCount;
	int timeCount;

	// If a single object is removed from a list, at the next frame update, the list must be sorted
	// Objects are sorted during a GlobalUpdate();
	// Sections must be checked and re configured during Wall, statCirc, and Hinge sorts
	// Specific sections are flagged on a removal of these objects
	bool	circSort;
	bool	wallSort;
	bool	statCircSort;
	bool	hingeSort;
//	bool	particleSort; // Not even worth it for Particles

};
