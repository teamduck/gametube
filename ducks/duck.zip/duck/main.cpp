/*	DUCK MASSACRE		*/
/*	By XiGency & Slasher	*/
/* //////////////////////////// */
/*	Greg Tourville		*/
/*	Matt Thomas		*/
/* //////////////////////////// */
/*  	Aug 17th 2006	 	*/
/* //////////////////////////// */

// TODO List
//
// Time Left: 2 days and a little time
//
// X	Basic Input
// X	3D Engine
// X	Game Prototype
// X	Physics Engine
// X	Network Prototype
// X	Bobbing
// X	3D Models
// X	Textures
// X	Network Framework		(Almost Done)
//	Network Finished
//	Shooting
//	Sound				(Easy)
//	Blood Effects			(Easy)
//	Corpse Effects			(Easy)
//	Color Choice			(Easy)
// -	Input Configurations		(Easy yet tiresome)
//	In game score			(Easy?)
// -	Server Options			(Maybe)
// -	Gun Animations & Reloading	
// -	Accurate Bullet Collision
// ?	Respawn Effect CoolNess

// GU Crash Bug, Possible Solutions:
// a) TermGu() and re-Init() it			(Might Work, Prevents In Game Font Use)
// b) Use a PNG instead for fonts 		(Probably Works)
// c) Find a different way for in-game text	(Takes too long)
// d) 

// Possible Problems:
// 
// Names > 31 character could cause a crash
// Using Sprintf()
// Server Glitches
// 

/*		INCLUDES		*/


// PSP Libs	////

// PSP:
#include <pspkernel.h>
#include <pspdisplay.h>
#include <pspdebug.h>
#include <pspsdk.h>
#include <pspctrl.h>

// Overclocking
#include <psppower.h>

// C++:
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

// 3D Stuff:
#include <pspge.h>
#include <pspgu.h>
#include <pspgum.h>

// Timing:
#include <psprtc.h>


// My Libs	////
#include "physics.h"
#include "wlan.h"
#include "graphics.h"
#include "sound.h"
#include "config.h"
#include "models/modelLoad.cpp"


/*		DEFINES			*/

#define printf			pspDebugScreenPrintf

#define	MAP_HEIGHT		20
#define	MAP_WIDTH		10

#define WALL_HEIGHT		1

#define MOVE_SPEED		25.0f
#define	BOB_SPEED		720.0f

#define DUCK_SPEED		-6.0f
#define JUMP_SPEED		8.0f

#define	PLAYER_SIZE		0.85f


/*		GLOBALS			*/

// Config
CONFIGFILE	Config;

// Global Timing Variables
u64		thistime;
u64		oldtime;
double		dt;
double		fps;

Physics*	World;

// Definitions
int	game();


// Module info
PSP_MODULE_INFO("Wlan Test", 0x1000,1,1);
PSP_MAIN_THREAD_ATTR(0);


#include	"network.cpp"
#include	"input.cpp"
#include	"font.cpp"
#include	"render.cpp"
#include	"game.cpp"


// TODO: input.cpp and game.cpp

/*		Callbacks		*/
/* Exit callback */
int exit_callback(int arg1, int arg2, void *common)
{
	sceKernelExitGame();

	// End the User Main Thread
//	sceKernelTerminateThread(uthid);	
	return 0;
}

/* Callback thread */
int CallbackThread(SceSize args, void *argp)
{
	int cbid;
	cbid = sceKernelCreateCallback("Exit Callback", exit_callback, NULL);
	sceKernelRegisterExitCallback(cbid);
	sceKernelSleepThreadCB();
	return 0;
}

/* Sets up the callback thread and returns its thread id */
int SetupCallbacks(void)
{
	int thid = 0;
	thid = sceKernelCreateThread("update_thread", CallbackThread, 0x11, 0xFA0, 0, 0);
	if(thid >= 0) sceKernelStartThread(thid, 0, 0);
	return thid;
}

/*		FUNCTIONS		*/
int	Game_Init()
{
	// Load Config
	
	printf("Loading Config \n");
	// Tries to load locally first
	read_config("ms0:/PSP/Game/Quak/config.txt", &Config);

	// Other wise, loads ms0:/duckconfig.txt
	if ( !Config.Read ) read_config("ms0:/quakconfig.txt", &Config);

	if ( Config.DebugMode ) pspDebugScreenInit();
	
	printf("Loading & Initializing Graphics \n");	
	// Init Graphics
	// (Dont Use InitGraphics, use setupGu()
	if ( !Config.DebugMode )
		if ( !initGraphics() ) return 0;
//	setupGu();

	printf("Initializing Matrices \n");	
	// Init the Physics World
	if ( !initPhysics() ) return 0;

	printf("Initializing Wirless Network \n");	
	// Init Wlan
	if ( !initWlan() ) return 0;

	printf("Configuring Controls \n");	
	// Init the Controls
	initInput();

	printf("Initializing Sound \n");	
	// Init Sound
	initMikmod();

	return 1;
}

int	Game_Shutdown()
{

	printf("Shutting Down \n");	

	sceKernelDelayThread(4000*1000);
	// Shutdown Graphics
//	if ( GraphicsLoaded ) 
	if ( !Config.DebugMode )
		shutdownGraphics();
//	else
//		shutdownGu();

	// Unload the Physics World
	shutdownPhysics();

	// Shutdown WLAN
	shutdownWlan();

	// Shutdown sound
	unloadMikmod();

	
	return 1;
}


///////////// MAIN FUNCTION /////////////////
int user_main( SceSize argc, void *argp )
{

	// Setup the Home button exit
	SetupCallbacks();
	
	// Initiate
//	printf("Duck... Loading \n");	
	Game_Init();

	if (Config.Overclock) scePowerSetClockFrequency(333, 333, 166);

	// Game
	
	// Server Menu
	// (loops)

	int id;	
	int numGames;
	ShortInfo* Games;	
	
	for(;;)
	{
		printf("Config says server is %s:%i \n",Config.MasterServer, Config.Port);
		printf("Trying to get IP from master server \n");
	
		// Try to get our IP twice
		// If that doesnt work, then tough luck, we exit
		if ( !getIp() )
			if ( !getIp() )
			{
				Game_Shutdown();
				return 0;
			}
		
		printf("Your IP is %s \n", Player1.IP);
		printf("Trying to get Games list \n");
	

		// Give it 2 trys, like the IP
		Games = getGameList( &numGames );
		if ( Games == NULL && numGames )
		{
			Games = getGameList( &numGames );
			if ( Games == NULL && numGames )
			{
				Game_Shutdown();
				return 0;
			}
		}


		printf("There are %i games running \n",numGames);
		printf("Going to game browser \n");

		// Go to the game browser
		// If it returns -1, then start a server, if it returns 0 quit, otherwise join that game (id)
//		if ( Config.Game == -1 )
			id = gameBrowser( numGames, Games );	
//		else
//		{
//			id = Config.Game;
//			if ( id == 0 ) id = -1;
//		}

		if (id == 0)
		{
			break;
		} else if ( id == -1 ) {
			newGame();
//			break;
		} else {
			joinGame(id);
//			break;
		}


		// Replace this with something that clears everything
		// So that it's safe to join another game
		break;

	}


	// Shutdown
	Game_Shutdown();
	
	return 1;
}


/* Start the User Thread */
int main(int argc, char **argv)
{
	// Initiate
//	pspDebugScreenInit();
	
	// Load Inet Modules
	printf("Loading inet modules\n");
	if(pspSdkLoadInetModules() < 0)
	{
		printf("Error, could not load inet modules\n");
		sceKernelDelayThread(2000*1000);
		sceKernelExitGame();
	}
	
	// Create user thread, tweek stack size here if necessary
	int uthid = sceKernelCreateThread("User Mode Thread", user_main,
	    0x11, // default priority
	    256 * 1024, // stack size (256KB is regular default)
	    PSP_THREAD_ATTR_USER, NULL);
	
	// start user thread, then wait for it to do everything else
	sceKernelStartThread(uthid, 0, NULL);
	sceKernelWaitThreadEnd(uthid, NULL);

	sceKernelExitGame();
	return 0;
}
