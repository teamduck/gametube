#ifndef __CONF_H__
#define __CONF_H__

typedef struct
{
	// Player Settings
	char 	PlayerName[32];
	int	PlayerThreshhold;
	float	PlayerSensitivity;
	int	PlayerControls;
	int 	PlayerColor;	
	
	// Server Settings
	char 	ServerName[32];
	short	ServerMaxPlayers;

	// Network Settings	
	char	MasterServer[64];
	int	Port;
	int	ConnectionNum;

	// Visual Settings
	bool	Outlines;

	// Performance Settings
	bool	Overclock;
	bool	Vsync;

	// Debug Settings
	bool	DebugMode;
	int	ConnectTime;
	int	ConnectTries;
	int	BufferSize;
	int	NumTempSockets;
	int	Timeout;
	int	InitialConnectTimeout;

	// Config Settings
	bool	Read;


	int	Game;

} CONFIGFILE;

void read_config(const char *file, CONFIGFILE *config);

#endif 

/* Example
//////////
CONFIGFILE
//////////

// Set a configfile
CONFIGFILE config;

// Whenever you want to read from the config file
read_config("ms0:/config.txt", &config);

// Based on this example, In that config file it's going to look for
name = "Something";
// and then return "Something" to config->name
// so config->name is going to hold the char Something

*/
