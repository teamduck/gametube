/*	Greg Tourville's Original Physics Engine
 *	Copyright 2006 Greg Tourville
 *	August 9th, 2006
 *	----------------------------
 *	By Greg aka XiGency
**/

#define	NULL		0L
//#define SLOW_WALLS

#include <math.h>
#include "physics.h"

inline float fastsqrt(float c) 
{ 
float output; 
asm("sqrt.s %0,%1" : "=f" (output) : "f" (c)); 
return output; 
} 


// Constructor
Physics::Physics()
{	// Fill Pointer Arrays with NULL's
	int i, x, y;
	for ( x = 0; x < MAX_SECTIONS_X; x++ )
		for ( y = 0; y < MAX_SECTIONS_Y; y++ )
			Sections[x][y] = NULL;

	for ( i = 0; i < MAX_CIRCLES; i++ )
		Circles[i] = NULL;

	for ( i = 0; i < MAX_WALLS; i++ )
		Walls[i] = NULL;

	for ( i = 0; i < MAX_HINGES; i++ )
		Hinges[i] = NULL;

	for ( i = 0; i < MAX_PARTICLES; i++ )
		Particles[i] = NULL;	

	// Set options
	FRICTION = 0.0f;
	GRAVITY = 0.0f;
	GRAVITY_ANGLE = 0.0f;
	LOSS_OF_ENERGY = 0.0f;

	nid = 0;
}

// Deconstructor
Physics::~Physics()
{	// Delete all none NULL pointers
	int i, x, y;
	for ( x = 0; x < MAX_SECTIONS_X; x++ )
		for ( y = 0; y < MAX_SECTIONS_Y; y++ )
			if ( Sections[x][y] != NULL )
				delete Sections[x][y];

	for ( i = 0; i < MAX_CIRCLES; i++ )
		if ( Circles[i] != NULL )
			delete Circles[i];

	for ( i = 0; i < MAX_WALLS; i++ )
		if ( Walls[i] != NULL )
			delete Walls[i];

	for ( i = 0; i < MAX_HINGES; i++ )
		if ( Hinges[i] != NULL )
			delete Hinges[i];

	for ( i = 0; i < MAX_PARTICLES; i++ )
		if ( Particles[i] != NULL )
			delete Particles[i];
}

int Physics::Initialize()
{
	int x, y, i, z;
	for ( x = 0; x < SectionsX; x++ )
		for ( y = 0; y < SectionsY; y++ )	// Make the sections
		{
			Sections[x][y] = new Section;

			// Clear it
			clearSection( Sections[x][y] );

			// Add Walls
			for ( z = 0; z < MAX_WALLS; z++ )
				if ( Walls[z] != NULL )
					// If its within this partition
					if ( Walls[z]->x1 >= (x*SectionWidth) && Walls[z]->x1 < ((x+1)*SectionWidth)
						&& Walls[x]->y1 >= (y*SectionHeight) && Walls[z]->y1 < ((y+1)*SectionHeight))
					
						// Find an empty one
						for ( i = 0; i < SECTION_WALLS; i++ )
							if ( Sections[x][y]->Walls[i] == NULL )
							{	// Add it
								Sections[x][y]->Walls[i] = Walls[z];
								break;
							}

			// Add Hinges
			for ( z = 0; z < MAX_HINGES; z++ )
				if ( Hinges[z] != NULL )
					// If its within this partition
					if ( Hinges[z]->x >= (x*SectionWidth) && Hinges[z]->x < ((x+1)*SectionWidth)
						&& Hinges[x]->y >= (y*SectionHeight) && Hinges[z]->y < ((y+1)*SectionHeight))
					
						// Find an empty one
						for ( i = 0; i < SECTION_HINGES; i++ )
							if ( Sections[x][y]->Hinges[i] == NULL )
							{	// Add it
								Sections[x][y]->Hinges[i] = Hinges[z];
								break;
							}
			
			// Add StatCircles

		}

	return 1;
}

int Physics::AddCircle( ColCircle* source )
{
	int i;
	for ( i = 0; i < MAX_CIRCLES; i++ )
	{
		if ( Circles[i] == NULL ) break;
	}

	if ( i < MAX_CIRCLES )
	{
		Circles[i] = source;
//		Circles[i]->id = nid;
//		nid++;
		return i;
	} else {
		return -1;	// Full
	}
}

int Physics::RemoveCircle( int index, bool del )			// By index
{
	if ( Circles[index] != NULL )
	{
		if ( del ) delete Circles[index];

		Circles[index] = NULL;
		return 1;
	} else {
		return -1;
	}
}

int Physics::AddWall( ColWall* source )			// Pass a struct* and added to list, returns index
{
	int i;
	for ( i = 0; i < MAX_WALLS; i++ )
	{
		if ( Walls[i] == NULL ) break;
	}

	if ( i < MAX_WALLS )
	{
		Walls[i] = source;
		return i;
	} else {
		return -1;	// Full
	}
}

int Physics::RemoveWall( int index, bool del )			// By index
{
	if ( Walls[index] != NULL )
	{
		// Find section
		int x, y, i;
		x = (int)(Walls[index]->x1 / SectionWidth);
		y = (int)(Walls[index]->y1 / SectionHeight);
		
		for ( i =0; i < SECTION_WALLS; i++ )
			if ( Sections[x][y]->Walls[i] == Walls[index] )
			{
				Sections[x][y]->Walls[i] = NULL;
//				Sections[x][y]->wallSort = true;
				break;
			}

		if ( del ) delete Walls[index];

		Walls[index] = NULL;
		return 1;
	} else {
		return -1;
	}
}

int Physics::AddHinge( ColHinge* source )
{
	int i;
	for ( i = 0; i < MAX_HINGES; i++ )
	{
		if ( Hinges[i] == NULL ) break;
	}

	if ( i < MAX_HINGES )
	{
		Hinges[i] = source;
		return i;
	} else {
		return -1;	// Full
	}
}

int Physics::RemoveHinge( int index, bool del )
{
	if ( Hinges[index] != NULL )
	{
		// Find section
		int x, y, i;
		x = Hinges[index]->x / SectionWidth;
		y = Hinges[index]->y / SectionHeight;
		
		for ( i =0; i < SECTION_HINGES; i++ )
			if ( Sections[x][y]->Hinges[i] == Hinges[index] )
			{
				Sections[x][y]->Hinges[i] = NULL;
//				Sections[x][y]->hingeSort = true;
				break;
			}

		if ( del ) delete Hinges[index];

		Hinges[index] = NULL;
		return 1;
	} else {
		return -1;
	}
}

int Physics::AddParticle( ColParticle* source )
{
	int i;
	for ( i = 0; i < MAX_PARTICLES; i++ )
	{
		if ( Particles[i] == NULL ) break;
	}

	if ( i < MAX_PARTICLES )
	{
		Particles[i] = source;
		return i;
	} else {
		return -1;	// Full
	}
}


/* ///////////	UPDATE	/////////////////	*/
int Physics::GlobalUpdate( double dt )
{
	CircleUpdate( dt );

	return 1;
};

int Physics::CircleUpdate( double dt )
{
	// CIRCLE UPDATE ///////////////////////
	// & BOUNDRIE COLLISION ////////////////
	int i, z;
	for ( i = 0; i < MAX_CIRCLES; i++ )
	{
		if ( Circles[i] != NULL )
		{
			circleUpdate( Circles[i], dt );
		}
	}



	// Circle Collisions	///////////////////////////////
	for ( i = 0; i < MAX_CIRCLES; i++ )
	{
		if ( Circles[i] != NULL )
		{
			for ( z = 0; z < MAX_CIRCLES; z++ )
			{
				if ( Circles[z] != NULL && z != i )
				{
					ColCircle* r = Circles[z];
					ColCircle* b = Circles[i];

					circleCircleCollision( r, b );
				}
			}
		}
	}

	return 1;
};



// Auxiliary Functions
int	clearSection( Section* s )
{
	int i;
	for ( i = 0; i < SECTION_WALLS; i++ )
		s->Walls[i] = NULL;

	for ( i = 0; i < SECTION_HINGES; i++ )
		s->Hinges[i] = NULL;

//	for ( i = 0; i < SECTION_CIRCLES; i++ )
//		s->CIRCLES[i] = NULL;

	return 1;
}


int Physics::circleUpdate( ColCircle* b, double dt )
{
	// Update Forces
	b->x += (b->xsp*dt);
	b->y += (b->ysp*dt);

	// Frictions
	// Kind 0 = Box, 1 = Player1, 2 = Net Player
	if ( b->kind != 2 )
	{	// Interpolate Net Players by not applying friction
		if ( FRICTION != 0.0f )
		{
			b->xsp -= (b->xsp * FRICTION * dt);
			b->ysp -= (b->ysp * FRICTION * dt);
		}
	}


	// Outer Boundries
	if ( b->x - b->size < LEFT_X )
	{
		b->x = (float)(LEFT_X  + b->size);
		if ( b->xsp < 0.0f )
			b->xsp = -b->xsp * (1.0f-LOSS_OF_ENERGY);
	} else if ( b->x  + b->size > RIGHT_X ) {
		b->x = (float)(RIGHT_X - b->size);
		if ( b->xsp > 0.0f )
			b->xsp = -b->xsp * (1.0f-LOSS_OF_ENERGY);
	}
	if ( b->y - b->size < UPPER_Y )
	{
		b->y = (float)(UPPER_Y + b->size);
		if ( b->ysp < 0.0f )
			b->ysp = -b->ysp * (1.0f-LOSS_OF_ENERGY);
	} else if ( b->y + b->size > LOWER_Y ) {
		b->y = (float)(LOWER_Y - b->size);
		if ( b->ysp > 0.0f )
			b->ysp = -b->ysp * (1.0f-LOSS_OF_ENERGY);
	}

	return 1;
}


int Physics::circleWallCollision( ColCircle* b, ColWall* w )
{
	/*
	// Possible Collision

	// Point 1

	float d = (w->size + b->size);
	float p1Dist = fastsqrt( (float)(( w->x1 - b->x )*( w->x1 - b->x ) + ( w->y1 - b->y )*( w->y1 - b->y )) );

	// Definitive Check
	if ( p1Dist < d )
	{
		double angle = atan2( b->x - w->x1, b->y - w->y1 );
		
		b->x = w->x1 + sin(angle) * d;
		b->y = w->y1 + cos(angle) * d;
	}
	

	// Point 2

	// Quick Check
	if ( (fabs( w->x2 - b->x ) + fabs( w->y2 - b->y ) ) < (d*1.5f) )
	{	// Definitive Check
		if ( ( ( w->x2 - b->x )*( w->x2 - b->x ) + ( w->y2 - b->y )*( w->y2 - b->y ) ) < (d*d) )
		{
			double angle = atan2( b->x - w->x2, b->y - w->y2 );
			
			b->x = w->x2 + sin(angle) * d;
			b->y = w->y2 + cos(angle) * d;
		}
	}

	// Line
	double ang1, ang2, angL1, angL2, dif1, dif2, ang, shortDist;
	ang1 = (atan2(b->x-w->x1,b->y-w->y1));
	ang2 = (atan2(b->x-w->x2,b->y-w->y2));
	angL1 = (atan2((float)(w->x2-w->x1),(float)(w->y2-w->y1)));
	angL2 = (atan2((float)(w->x1-w->x2),(float)(w->y1-w->y2)));
	dif1 = fabs(angL1 - ang1);
	dif2 = fabs(angL2 - ang2);

	// Is it between the two points
	if ( (cos(dif1) >= 0.0f) && (cos(dif2) >= 0.0f) )
	{
		ang = dif1;

		shortDist = fabs(sin(ang) * p1Dist);

		// Collision
		if ( shortDist < d )
		{
			float cx, cy;
			// Collision!
			float lineDist = cos(ang) * p1Dist;
			cx = w->x1 + (sin(angL1) * lineDist);
			cy = w->y1 + (cos(angL1) * lineDist);

			ang = atan2(b->x-cx,b->y-cy);

			// Fix the position
			b->x = cx + sin(ang)*(d);
			b->y = cy + cos(ang)*(d);

			// Reflect
			double Angle1a, Angle1b, speed;
			Angle1a = atan2(b->xsp, b->ysp);
			Angle1b = ( (angL1*2) - (Angle1a) );
			speed = fastsqrt( (float)((b->xsp*b->xsp) + (b->ysp*b->ysp)) );
			b->xsp = sin(Angle1b) * speed * (1.0f - LOSS_OF_ENERGY);
			b->ysp = cos(Angle1b) * speed * (1.0f - LOSS_OF_ENERGY);

			// Check for roll++


		}
	}

	*/

	return 1;
}


int Physics::circleCircleCollision( ColCircle* r, ColCircle* b )
{
	float d = b->size + r->size;

	// Quick Check
	if (( fabs( b->x - r->x ) + fabs( b->y - r->y ) ) < (d*1.5f))
	{
		// Definite check
		float distance = ( ( b->x - r->x )*( b->x - r->x ) + ( b->y - r->y )*( b->y - r->y ) );
		if ( distance < (d*d) )
		{
			// Fix overlap
			float centerX, centerY;
			centerX = (b->x + r->x)/2;
			centerY = (b->y + r->y)/2;

			float ang = atan2(b->x - centerX, b->y - centerY);
			float hd = (float)(d)/2;

			// Make distances based on mass or size?
			b->x = centerX + sin(ang)*hd;
			b->y = centerY + cos(ang)*hd;
			
			r->x = centerX - sin(ang)*hd;
			r->y = centerY - cos(ang)*hd;


			// Apply Friction?



		}
	}

	return 1;
}
