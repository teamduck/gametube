// Defines
#define BUF_WIDTH (512)
#ifndef SCR_WIDTH
	#define SCR_WIDTH		480
#endif
#ifndef SCR_HEIGHT	
	#define SCR_HEIGHT		272
#endif
#define PIXEL_SIZE (4) /* change this if you change to another screenmode */
#define FRAME_SIZE (BUF_WIDTH * SCR_HEIGHT * PIXEL_SIZE)
#define ZBUF_SIZE (BUF_WIDTH SCR_HEIGHT * 2) /* zbuffer seems to be 16-bit? */
#define RGB(r, g, b) (0xFF000000 | ((b)<<16) | ((g)<<8) | (r))


#define GU_ABGR(a,b,g,r)	(((a) << 24)|((b) << 16)|((g) << 8)|(r))
#define GU_ARGB(a,r,g,b)	GU_ABGR((a),(b),(g),(r))
#define GU_RGBA(r,g,b,a)	GU_ARGB((a),(r),(g),(b))
#define GU_COLOR(r,g,b,a)	GU_RGBA((u32)((r) * 255.0f),(u32)((g) * 255.0f),(u32)((b) * 255.0f),(u32)((a) * 255.0f))

// Globals
static unsigned int __attribute__((aligned(16))) list[262144];
extern void* frameBuffer;
extern void* doubleBuffer;
extern void* depthBuffer;

typedef u32 Color;

struct		Image
{
	int textureWidth;  // the real width of data, 2^n with n>=0
	int textureHeight;  // the real height of data, 2^n with n>=0
	int imageWidth;  // the image width
	int imageHeight;
	Color* data;
};


struct		Texture
{
	// Variables:
	Image*		sysram;
	void*		vidram;
	int			width, height;

	// Functions:
	int		assign();
	int		load( const char* path );
	int		unload();
	int		vram();
	int		unvram();
	bool	isvram();

};

// Structs
struct Vertex
{
	float u, v;
	unsigned int color;
	float x,y,z;
};

typedef struct _point2 {
	double x,y;
} Point2;

typedef struct _point3 {
	double x,y,z;
} Point3;


int 	setupGu( bool debug );
int	shutdownGu();
